%This Matlab script can be used to generate the Figures 8 and 9 in the article:
%
%José Carlos Marinello Filho, Taufik Abrão, Ekram Hossain, and Amine Mezghani, 
%"Reconfigurable Intelligent Surfaces-Enabled Intra-Cell Pilot Reuse in Massive MIMO Systems"
%
%This is version 1.1 (Last edited: 2023-07-20)
%
%License: This code is licensed under the GPLv2 license. If you in any way
%use this code for research that results in publications, please cite our
%original article listed above.

%Initialization
%close all;
clear;
clc;

% Defining functions
u = @(phi,N,d)exp(-1i*pi*phi*transpose(0:N-1));
ar = @(phi,theta,Mh,Mv,d,lbd)kron(u((2*d/lbd)*sin(phi)*cos(theta),Mh,d),u((2*d/lbd)*sin(theta),Mv,d)); %fix first varying second
rice = @(rfac,los,M,N)sqrt(rfac/(rfac+1))*los+sqrt(1/(2*(rfac+1)))*(randn(M,N)+1i*randn(M,N));

% Select correlation model for the RIS-UEs link
CorrModel = 1; % Sinc-shaped correlation model
%CorrModel = 2; % Exponential correlation model

%Define the variables in each of the simulations

%Length of pilot sequences
tp = 4;

%Number of clusters and PRF
ncvalues = 2:7; 

%Number of UEs per BS
Kvalues = tp*ncvalues;
Kmax = Kvalues(end);

%Select range of number of BS antennas
%Mrange = [8 16 32 64 128 256];
M = 128;

%Correlation factor in exponential correlation model
correlationFactor = 0.5;

%Number of points on the horizontal axis in the final figure
nbrOfPoints = length(Kvalues);

%Select number of channel realizations per setup
nbrOfRealizations = 1000;

%Cell Radius
cellRadius = 150;

%Define BS positions using complex coordinates
BSlocations = 0;

% Propagation parameters
f = 3e9;
lbd = 3e8/f;
da = lbd/2;

% Optimized grid of angular positions for the RIS deployment
N_angs = M*da/lbd;
step_ang = 1/N_angs;
AoAa_opt = zeros(4*N_angs,1);
for ind=-N_angs:N_angs
    AoAa_opt(N_angs+1+ind) = asin(ind*step_ang); %asin(2*ind/M);
end
AoAa_opt(2*N_angs+2:end) = AoAa_opt(2:2*N_angs)+pi;
numElelCircShift = sum(AoAa_opt<0);
AoAa_opt(AoAa_opt<0) = AoAa_opt(AoAa_opt<0)+2*pi;
AoAa_opt = circshift(AoAa_opt,-numElelCircShift);
% figure
% polarplot(AoAa_opt,ones(size(AoAa_opt)),'r+')
% figure
% plot(AoAa_opt,'r+')

%Pathloss exponent
alpha = 4.2; % no-RIS UEs
alpha2 = 4.2; % RIS-aided UEs

%Constant term in pathloss model (assuming distances in meters)
constantTerm = -35.3;

%Communication bandwidth
bandwidth = 10e6;

%Define total uplink transmit power per UE (mW)
p = 100;

%Define total downlink transmit power per UE (mW)
rho = 100;

%Define noise figure at BS (in dB)
noiseFigure = 10;

%Compute total noise power
noiseVariancedBm = -174 + 10*log10(bandwidth) + noiseFigure;

%Select length of coherence block
tau_c = 200;


% RIS parameters
Ni = 256;
Nv = 64;
Nh = Ni/Nv;
di = lbd/2;
Riceai_dB = 5;
Riceai = 10.^(Riceai_dB/10);
plexp_ai = 2.3;
elAoD_i = 0;
h_BS = 10;
%elAoD_i = atan(h_BS/(0.2*cellRadius));
AoD_ris = pi/6;
azAoD_i = AoD_ris;

if CorrModel == 1
    % RIS correlation matrix under sinc-shaped model
    Rris = zeros(Ni);
    for indr=1:Ni
        for indc=1:Ni
            col_indr = ceil(indr/Nv);
            row_indr = mod(indr-1,Nv)+1;
            col_indc = ceil(indc/Nv);
            row_indc = mod(indc-1,Nv)+1;
            dist_elem = sqrt((col_indr - col_indc)^2+(row_indr - row_indc)^2)*di;

            Rris(indr,indc) = sinc(dist_elem/(lbd/2));
        end
    end
end

% Create the problem structure.
manifold = complexcirclefactory(Ni);
problem.M = manifold;

%Prepare to save UL simulation results
% 1st line: Closest UEs
% 2nd line: Farthest UEs
% 3rd line: All UEs

meanSEperUE_MR = zeros(3,nbrOfPoints);
meanSEperUE_MMSE = zeros(3,nbrOfPoints);
meanSEperUE_ZF = zeros(3,nbrOfPoints);

meanSEperUE_MR_mo = zeros(3,nbrOfPoints);
meanSEperUE_MMSE_mo = zeros(3,nbrOfPoints);
meanSEperUE_ZF_mo = zeros(3,nbrOfPoints);

meanSEperUE_MR_nr = zeros(3,nbrOfPoints);
meanSEperUE_MMSE_nr = zeros(3,nbrOfPoints);
meanSEperUE_ZF_nr = zeros(3,nbrOfPoints);

meanSignPilots_rps = zeros(1,nbrOfPoints);
meanSignPilots_mo = zeros(1,nbrOfPoints);
meanSignPilots_nr = zeros(1,nbrOfPoints);

meanCorrProd_rps = zeros(2,nbrOfPoints);
meanCorrProd_mo = zeros(2,nbrOfPoints);
meanCorrProd_nr = zeros(2,nbrOfPoints);

meanStVecProd = zeros(1,nbrOfPoints);

%Prepare to save DL simulation results
% 1st line: Closest UEs
% 2nd line: Farthest UEs
% 3rd line: All UEs

meanSEperUE_MR_DL = zeros(3,nbrOfPoints);
meanSEperUE_MMSE_DL = zeros(3,nbrOfPoints);
meanSEperUE_ZF_DL = zeros(3,nbrOfPoints);

meanSEperUE_MR_mo_DL = zeros(3,nbrOfPoints);
meanSEperUE_MMSE_mo_DL = zeros(3,nbrOfPoints);
meanSEperUE_ZF_mo_DL = zeros(3,nbrOfPoints);

meanSEperUE_MR_nr_DL = zeros(3,nbrOfPoints);
meanSEperUE_MMSE_nr_DL = zeros(3,nbrOfPoints);
meanSEperUE_ZF_nr_DL = zeros(3,nbrOfPoints);

%Prepare to store simulation results for UL signal gains
% 1st line: Closest UEs
% 2nd line: Farthest UEs
% 3rd line: All UEs

signal_MR_phi1_avg = zeros(3,nbrOfPoints);
EstErr_MR_phi1_avg = zeros(3,nbrOfPoints);
InterfRP_MR_phi1_avg = zeros(3,nbrOfPoints);
InterfNRP_MR_phi1_avg = zeros(3,nbrOfPoints);

signal_MR_phi2_avg = zeros(3,nbrOfPoints);
EstErr_MR_phi2_avg = zeros(3,nbrOfPoints);
InterfRP_MR_phi2_avg = zeros(3,nbrOfPoints);
InterfNRP_MR_phi2_avg = zeros(3,nbrOfPoints);

signal_MR_nris_avg = zeros(3,nbrOfPoints);
EstErr_MR_nris_avg = zeros(3,nbrOfPoints);
InterfRP_MR_nris_avg = zeros(3,nbrOfPoints);
InterfNRP_MR_nris_avg = zeros(3,nbrOfPoints);

signal_ZF_phi1_avg = zeros(3,nbrOfPoints);
EstErr_ZF_phi1_avg = zeros(3,nbrOfPoints);
InterfRP_ZF_phi1_avg = zeros(3,nbrOfPoints);
InterfNRP_ZF_phi1_avg = zeros(3,nbrOfPoints);

signal_ZF_phi2_avg = zeros(3,nbrOfPoints);
EstErr_ZF_phi2_avg = zeros(3,nbrOfPoints);
InterfRP_ZF_phi2_avg = zeros(3,nbrOfPoints);
InterfNRP_ZF_phi2_avg = zeros(3,nbrOfPoints);

signal_ZF_nris_avg = zeros(3,nbrOfPoints);
EstErr_ZF_nris_avg = zeros(3,nbrOfPoints);
InterfRP_ZF_nris_avg = zeros(3,nbrOfPoints);
InterfNRP_ZF_nris_avg = zeros(3,nbrOfPoints);

signal_MMSE_phi1_avg = zeros(3,nbrOfPoints);
EstErr_MMSE_phi1_avg = zeros(3,nbrOfPoints);
InterfRP_MMSE_phi1_avg = zeros(3,nbrOfPoints);
InterfNRP_MMSE_phi1_avg = zeros(3,nbrOfPoints);

signal_MMSE_phi2_avg = zeros(3,nbrOfPoints);
EstErr_MMSE_phi2_avg = zeros(3,nbrOfPoints);
InterfRP_MMSE_phi2_avg = zeros(3,nbrOfPoints);
InterfNRP_MMSE_phi2_avg = zeros(3,nbrOfPoints);

signal_MMSE_nris_avg = zeros(3,nbrOfPoints);
EstErr_MMSE_nris_avg = zeros(3,nbrOfPoints);
InterfRP_MMSE_nris_avg = zeros(3,nbrOfPoints);
InterfNRP_MMSE_nris_avg = zeros(3,nbrOfPoints);

%Prepare to store simulation results for DL signal gains
% 1st line: Closest UEs
% 2nd line: Farthest UEs
% 3rd line: All UEs

% desSign_MR_DL_phi1 = zeros(3,nbrOfPoints);
% selfInt_MR_DL_phi1 = zeros(3,nbrOfPoints);
% IntPR_MR_DL_phi1 = zeros(3,nbrOfPoints);
% IntNPR_MR_DL_phi1 = zeros(3,nbrOfPoints);
% 
% desSign_ZF_DL_phi1 = zeros(3,nbrOfPoints);
% selfInt_ZF_DL_phi1 = zeros(3,nbrOfPoints);
% IntPR_ZF_DL_phi1 = zeros(3,nbrOfPoints);
% IntNPR_ZF_DL_phi1 = zeros(3,nbrOfPoints);
% 
% desSign_MMSE_DL_phi1 = zeros(3,nbrOfPoints);
% selfInt_MMSE_DL_phi1 = zeros(3,nbrOfPoints);
% IntPR_MMSE_DL_phi1 = zeros(3,nbrOfPoints);
% IntNPR_MMSE_DL_phi1 = zeros(3,nbrOfPoints);
% 
% desSign_MR_DL_phi2 = zeros(3,nbrOfPoints);
% selfInt_MR_DL_phi2 = zeros(3,nbrOfPoints);
% IntPR_MR_DL_phi2 = zeros(3,nbrOfPoints);
% IntNPR_MR_DL_phi2 = zeros(3,nbrOfPoints);
% 
% desSign_ZF_DL_phi2 = zeros(3,nbrOfPoints);
% selfInt_ZF_DL_phi2 = zeros(3,nbrOfPoints);
% IntPR_ZF_DL_phi2 = zeros(3,nbrOfPoints);
% IntNPR_ZF_DL_phi2 = zeros(3,nbrOfPoints);
% 
% desSign_MMSE_DL_phi2 = zeros(3,nbrOfPoints);
% selfInt_MMSE_DL_phi2 = zeros(3,nbrOfPoints);
% IntPR_MMSE_DL_phi2 = zeros(3,nbrOfPoints);
% IntNPR_MMSE_DL_phi2 = zeros(3,nbrOfPoints);
% 
% desSign_MR_DL_nris = zeros(3,nbrOfPoints);
% selfInt_MR_DL_nris = zeros(3,nbrOfPoints);
% IntPR_MR_DL_nris = zeros(3,nbrOfPoints);
% IntNPR_MR_DL_nris = zeros(3,nbrOfPoints);
% 
% desSign_ZF_DL_nris = zeros(3,nbrOfPoints);
% selfInt_ZF_DL_nris = zeros(3,nbrOfPoints);
% IntPR_ZF_DL_nris = zeros(3,nbrOfPoints);
% IntNPR_ZF_DL_nris = zeros(3,nbrOfPoints);
% 
% desSign_MMSE_DL_nris = zeros(3,nbrOfPoints);
% selfInt_MMSE_DL_nris = zeros(3,nbrOfPoints);
% IntPR_MMSE_DL_nris = zeros(3,nbrOfPoints);
% IntNPR_MMSE_DL_nris = zeros(3,nbrOfPoints);

tr_R2 = zeros(ncvalues(end)-1,nbrOfPoints);

%Go through all points 
for m = 1:nbrOfPoints

    %Output simulation progress
    disp([num2str(m) ' points out of ' num2str(nbrOfPoints)]);

    %Extract current number of UEs
    K = Kvalues(m);
    nc = ncvalues(m);

    % Creating matrix of UEs sharing pilots
    indrp = zeros(K,nc);
    for ind=1:K
        indrp(ind,:) = (mod(ind-1,tp)+1):tp:K;
    end

    %Deploy UEs at the fixed locations
    D_ang_c = 2*pi/(nc);
    Angs_c = transpose(D_ang_c*((1:nc)-0.5)); % Angles of the RIS
    for indc=2:nc
        closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt)));
        Angs_c(indc) = AoAa_opt(closestInd);
        if abs(sin(Angs_c(indc)))==1
            indEqAng = abs(sin(Angs_c(2:indc-1)))-1<1e-5;
            if any(indEqAng)
                closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(closestInd-1)),abs(Angs_c(indc)-AoAa_opt(closestInd+1))),1);
                Angs_c(indc) = AoAa_opt(closestInd);
            end
        end
        indEqAng = abs(sin(Angs_c(indc))-sin(Angs_c(2:indc-1)))<1e-5;
        if any(indEqAng)
            closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(closestInd-1)),abs(Angs_c(indc)-AoAa_opt(closestInd+1))),1);
            Angs_c(indc) = AoAa_opt(closestInd);
        end
    end
    Dang_ris = pi/2; % Angle sector to distribute UEs
    D_ang_ues = Dang_ris/(tp+1);
    Angs_ue_c = transpose(D_ang_ues*(1:tp));
    posRIS = 0.8*cellRadius*exp(1i*Angs_c(2:nc));
    posUEs_c = 0.2*cellRadius*exp(1i*Angs_ue_c);
    posUEs = zeros(tp,nc);
    for ind=2:nc
        posUEs(:,ind) = (posUEs_c*exp(1i*(Angs_c(ind)-AoD_ris+pi/2)))+posRIS(ind-1);
    end
    posUEs(:,1) = 0.6*cellRadius*exp(1i*Angs_c(1))+0.1*cellRadius*exp(1i*(transpose(1:tp))*(2*pi/tp));
    posUE1 = posUEs(:,1);
    posUEs = posUEs(:,2:end);
    RIS_boresights = Angs_c- pi - AoD_ris;

    azAoA_a = angle(BSlocations-posRIS);

    %Prepare to store simulation results for UL signal gains

    signal_MR_phi1 = zeros(K,nbrOfRealizations);
    EfNoise_MR_phi1 = zeros(K,nbrOfRealizations);
    EstErr_MR_phi1 = zeros(K,nbrOfRealizations);
    InterfRP_MR_phi1 = zeros(K,nbrOfRealizations);
    InterfNRP_MR_phi1 = zeros(K,nbrOfRealizations);

    signal_MR_phi2 = zeros(K,nbrOfRealizations);
    EfNoise_MR_phi2 = zeros(K,nbrOfRealizations);
    EstErr_MR_phi2 = zeros(K,nbrOfRealizations);
    InterfRP_MR_phi2 = zeros(K,nbrOfRealizations);
    InterfNRP_MR_phi2 = zeros(K,nbrOfRealizations);

    signal_MR_nris = zeros(K,nbrOfRealizations);
    EfNoise_MR_nris = zeros(K,nbrOfRealizations);
    EstErr_MR_nris = zeros(K,nbrOfRealizations);
    InterfRP_MR_nris = zeros(K,nbrOfRealizations);
    InterfNRP_MR_nris = zeros(K,nbrOfRealizations);

    signal_ZF_phi1 = zeros(K,nbrOfRealizations);
    EfNoise_ZF_phi1 = zeros(K,nbrOfRealizations);
    EstErr_ZF_phi1 = zeros(K,nbrOfRealizations);
    InterfRP_ZF_phi1 = zeros(K,nbrOfRealizations);
    InterfNRP_ZF_phi1 = zeros(K,nbrOfRealizations);

    signal_ZF_phi2 = zeros(K,nbrOfRealizations);
    EfNoise_ZF_phi2 = zeros(K,nbrOfRealizations);
    EstErr_ZF_phi2 = zeros(K,nbrOfRealizations);
    InterfRP_ZF_phi2 = zeros(K,nbrOfRealizations);
    InterfNRP_ZF_phi2 = zeros(K,nbrOfRealizations);

    signal_ZF_nris = zeros(K,nbrOfRealizations);
    EfNoise_ZF_nris = zeros(K,nbrOfRealizations);
    EstErr_ZF_nris = zeros(K,nbrOfRealizations);
    InterfRP_ZF_nris = zeros(K,nbrOfRealizations);
    InterfNRP_ZF_nris = zeros(K,nbrOfRealizations);

    signal_MMSE_phi1 = zeros(K,nbrOfRealizations);
    EfNoise_MMSE_phi1 = zeros(K,nbrOfRealizations);
    EstErr_MMSE_phi1 = zeros(K,nbrOfRealizations);
    InterfRP_MMSE_phi1 = zeros(K,nbrOfRealizations);
    InterfNRP_MMSE_phi1 = zeros(K,nbrOfRealizations);

    signal_MMSE_phi2 = zeros(K,nbrOfRealizations);
    EfNoise_MMSE_phi2 = zeros(K,nbrOfRealizations);
    EstErr_MMSE_phi2 = zeros(K,nbrOfRealizations);
    InterfRP_MMSE_phi2 = zeros(K,nbrOfRealizations);
    InterfNRP_MMSE_phi2 = zeros(K,nbrOfRealizations);

    signal_MMSE_nris = zeros(K,nbrOfRealizations);
    EfNoise_MMSE_nris = zeros(K,nbrOfRealizations);
    EstErr_MMSE_nris = zeros(K,nbrOfRealizations);
    InterfRP_MMSE_nris = zeros(K,nbrOfRealizations);
    InterfNRP_MMSE_nris = zeros(K,nbrOfRealizations);

    %Prepare to store simulation results for DL signal gains

    signalDL_MR_phi1 = zeros(K,nbrOfRealizations);
    interf_PR_MR_phi1 = zeros(K,nbrOfRealizations);
    interf_NPR_MR_phi1 = zeros(K,nbrOfRealizations);

    signalDL_ZF_phi1 = zeros(K,nbrOfRealizations);
    interf_PR_ZF_phi1 = zeros(K,nbrOfRealizations);
    interf_NPR_ZF_phi1 = zeros(K,nbrOfRealizations);

    signalDL_MMSE_phi1 = zeros(K,nbrOfRealizations);
    interf_PR_MMSE_phi1 = zeros(K,nbrOfRealizations);
    interf_NPR_MMSE_phi1 = zeros(K,nbrOfRealizations);

    signalDL_MR_phi2 = zeros(K,nbrOfRealizations);
    interf_PR_MR_phi2 = zeros(K,nbrOfRealizations);
    interf_NPR_MR_phi2 = zeros(K,nbrOfRealizations);

    signalDL_ZF_phi2 = zeros(K,nbrOfRealizations);
    interf_PR_ZF_phi2 = zeros(K,nbrOfRealizations);
    interf_NPR_ZF_phi2 = zeros(K,nbrOfRealizations);

    signalDL_MMSE_phi2 = zeros(K,nbrOfRealizations);
    interf_PR_MMSE_phi2 = zeros(K,nbrOfRealizations);
    interf_NPR_MMSE_phi2 = zeros(K,nbrOfRealizations);

    signalDL_MR_nris = zeros(K,nbrOfRealizations);
    interf_PR_MR_nris = zeros(K,nbrOfRealizations);
    interf_NPR_MR_nris = zeros(K,nbrOfRealizations);

    signalDL_ZF_nris = zeros(K,nbrOfRealizations);
    interf_PR_ZF_nris = zeros(K,nbrOfRealizations);
    interf_NPR_ZF_nris = zeros(K,nbrOfRealizations);

    signalDL_MMSE_nris = zeros(K,nbrOfRealizations);
    interf_PR_MMSE_nris = zeros(K,nbrOfRealizations);
    interf_NPR_MMSE_nris = zeros(K,nbrOfRealizations);

    %Compute distances between UEs, BS and RIS
    distancesBS_RIS = abs(posRIS-BSlocations);
    distancesBS_UE1 = abs(posUE1-BSlocations);
    distancesBS_UEs = abs(posUEs-BSlocations);
    distancesRIS_UEs = abs(posUEs-repmat(transpose(posRIS),tp,1));

    %Compute angles between UEs, BS and RIS
    angleBS_UE1 = angle(posUE1-BSlocations);
    angleBS_UEs = angle(posUEs-BSlocations);
    angleRIS_UEs = angle(posUEs-repmat(transpose(posRIS),tp,1)) - repmat(transpose(RIS_boresights(2:end)),tp,1);% +pi/2;

    %Compute distant-dependent path gains (in dB) normalized by the noise power
    channelGaindB_BS_UE1 = constantTerm - alpha*10*log10(distancesBS_UE1) -noiseVariancedBm;
    channelGaindB_BS_UEs = constantTerm - alpha2*10*log10(distancesBS_UEs) -noiseVariancedBm;
    channelGaindB_BS_RIS = constantTerm - plexp_ai*10*log10(distancesBS_RIS) -noiseVariancedBm;
    channelGaindB_RIS_UEs = constantTerm - plexp_ai*10*log10(distancesRIS_UEs);

    %Go through all channels and apply path gain
    betas_BS_UE1 = 10.^(channelGaindB_BS_UE1/10);
    betas_BS_UEs = 10.^(channelGaindB_BS_UEs/10);
    betas_BS_RIS = 10.^(channelGaindB_BS_RIS/10);
    betas_RIS_UEs = 10.^(channelGaindB_RIS_UEs/10);


    Rris_UEs = zeros(Ni,Ni,tp,nc-1);
    for indc = 1:nc-1
        for indk = 1:tp
            if CorrModel == 1
                Rris_UEs(:,:,indk,indc) = betas_RIS_UEs(indk,indc)*Rris;
            elseif CorrModel == 2
                Rris_UEs(:,:,indk,indc) = betas_RIS_UEs(indk,indc)*toeplitz((correlationFactor*exp(1i*angleRIS_UEs(indk,indc))).^(0:Ni-1));
            end
        end
    end
    if CorrModel == 2
        Rris_sum = reshape(sum(Rris_UEs,3),[Ni Ni nc-1]);
    end


    %Generate covariance matrix using the exponential
    %correlation model
    Rue1 = zeros(M,M,tp);
    for indk = 1:tp
        Rue1(:,:,indk) = betas_BS_UE1(indk,1)*toeplitz((correlationFactor*exp(1i*angleBS_UE1(indk,1))).^(0:M-1));
    end
    Rues = zeros(M,M,tp,nc-1);
    H_ai_los = zeros(M,Ni,nc-1);
    H_ai = zeros(M,Ni,nc-1);
    Phi = zeros(Ni,nc-1);
    Rues_phi1 = zeros(M,M,tp,nc-1);
    Zmat = zeros(Ni,Ni,nc-1);
    for indc = 1:nc-1
        H_ai_los(:,:,indc) = u((2*da/lbd)*sin(azAoA_a(indc)),M,da)*ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd)'; % MxNi
        H_ai(:,:,indc) = sqrt(betas_BS_RIS(indc))*rice(Riceai,H_ai_los(:,:,indc),M,Ni);
        %Phi(:,indc) = ones(Ni,1);
        Phi(:,indc) = ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd);
        if CorrModel == 1
            Zmat(:,:,indc) = conj(Rris).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
        elseif CorrModel == 2
            Zmat(:,:,indc) = conj(Rris_sum(:,:,indc)).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
        end
        
        for indk=1:tp
            Rues(:,:,indk,indc) = betas_BS_UEs(indk,indc)*toeplitz((correlationFactor*exp(1i*angleBS_UEs(indk,indc))).^(0:M-1));
            Rues_phi1(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phi(:,indc))*Rris_UEs(:,:,indk,indc)*(H_ai(:,:,indc)*diag(Phi(:,indc)))' + Rues(:,:,indk,indc);
        end
    end

    %Generate uncorrelated Rayleigh fading channel realizations
    Hue1 = (randn(M,nbrOfRealizations,tp)+1i*randn(M,nbrOfRealizations,tp));
    Hues = (randn(M,nbrOfRealizations,tp,nc-1)+1i*randn(M,nbrOfRealizations,tp,nc-1));
    Hues_ris = (randn(Ni,nbrOfRealizations,tp,nc-1)+1i*randn(Ni,nbrOfRealizations,tp,nc-1));

    %Store identity matrix of size M x M
    eyeM = eye(M);

    %Apply covariance structure to the uncorrelated realizations
    Rsqrt_UE1 = zeros(size(Rue1));
    for indk=1:tp
        Rsqrt_UE1(:,:,indk) = sqrtm(Rue1(:,:,indk));
        Hue1(:,:,indk) = sqrt(0.5)*Rsqrt_UE1(:,:,indk)*Hue1(:,:,indk);
    end

    Rsqrt_UEs = zeros(M,M,tp,nc-1);
    Rrissqrt_UEs = zeros(Ni,Ni,tp,nc-1);
    Hues_phi1 = zeros(M,nbrOfRealizations,tp,nc-1);
    Hues_phi2 = zeros(M,nbrOfRealizations,tp,nc-1);
    Phiopt = zeros(Ni,nc-1);
    Rues_phi2 = zeros(M,M,tp,nc-1);
    for indc = 1:nc-1

        % Define the problem cost function and its Euclidean gradient.
        problem.cost  = @(x) -real(x'*Zmat(:,:,indc)*x);
        problem.egrad = @(x) -2*Zmat(:,:,indc)*x;      % notice the 'e' in 'egrad' for Euclidean

        % Numerically check gradient consistency (optional).
        %checkgradient(problem);

        % Solve
        [Phi2, xcost, info, options] = trustregions(problem);
        Phiopt(:,indc) = Phi2;

        tr_R2(indc,m) = -xcost;

        for indk=1:tp
            Rsqrt_UEs(:,:,indk,indc) = sqrtm(Rues(:,:,indk,indc));
            Hues(:,:,indk,indc) = sqrt(0.5)*Rsqrt_UEs(:,:,indk,indc)*Hues(:,:,indk,indc);
            Rrissqrt_UEs(:,:,indk,indc) = sqrtm(Rris_UEs(:,:,indk,indc));
            Hues_ris(:,:,indk,indc) = sqrt(0.5)*Rrissqrt_UEs(:,:,indk,indc)*Hues_ris(:,:,indk,indc);
            Hues_phi1(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phi(:,indc))*Hues_ris(:,:,indk,indc) + Hues(:,:,indk,indc);

            Rues_phi2(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phiopt(:,indc))*Rris_UEs(:,:,indk,indc)*(H_ai(:,:,indc)*diag(Phiopt(:,indc)))' + Rues(:,:,indk,indc);
            %Rue2_phi2 = H_ai_los*diag(Phiopt)*Rris*(H_ai_los*diag(Phiopt))' + Rue2;
            Hues_phi2(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phiopt(:,indc))*Hues_ris(:,:,indk,indc) + Hues(:,:,indk,indc);
        end
    end

    % Dimensions: M x MCt x tp x prf
    H_phi1 = cat(4,Hue1,Hues_phi1);    
    H_phi2 = cat(4,Hue1,Hues_phi2);
    H_nris = cat(4,Hue1,Hues);

    % MMSE estimation

    %Generate realizations of normalized noise
    Np = sqrt(0.5)*(randn(M,nbrOfRealizations,tp) + 1i*randn(M,nbrOfRealizations,tp));

    
    %Compute processed pilot signal for all UEs
    % Dimensions: M x MCt x tp
    Yp_phi1 = sqrt(p)*tp*sum(H_phi1,4) + sqrt(tp)*Np;
    Yp_phi2 = sqrt(p)*tp*sum(H_phi2,4) + sqrt(tp)*Np;
    Yp_nris = sqrt(p)*tp*sum(H_nris,4) + sqrt(tp)*Np;

    meanSignPilots_rps(1,m) = mean(abs(Yp_phi1),"all");
    meanSignPilots_mo(1,m) = mean(abs(Yp_phi2),"all");
    meanSignPilots_nr(1,m) = mean(abs(Yp_nris),"all");

    R_ext_phi1 = cat(4,Rue1,Rues_phi1);
    Prod_phi1 = zeros(nc,nc);
    R_ext_phi2 = cat(4,Rue1,Rues_phi2);
    Prod_phi2 = zeros(nc,nc);
    R_ext_nris = cat(4,Rue1,Rues);
    Prod_nris = zeros(nc,nc);
    for indc1=1:nc
        for indc2=1:nc
            for indk=1:tp
                Prod_phi1(indc1,indc2) = Prod_phi1(indc1,indc2) + real(trace(R_ext_phi1(:,:,indk,indc1)*R_ext_phi1(:,:,indk,indc2)))/(nc^2);
                Prod_phi2(indc1,indc2) = Prod_phi2(indc1,indc2) + real(trace(R_ext_phi2(:,:,indk,indc1)*R_ext_phi2(:,:,indk,indc2)))/(nc^2);
                Prod_nris(indc1,indc2) = Prod_nris(indc1,indc2) + real(trace(R_ext_nris(:,:,indk,indc1)*R_ext_nris(:,:,indk,indc2)))/(nc^2);
            end
        end
        if indc1~=1
            indc12 = indc1-1;
            for indc2=1:nc-1
                if indc2 ~=indc12
                    meanStVecProd(1,m) = meanStVecProd(1,m) + abs(u((2*da/lbd)*sin(azAoA_a(indc12)),M,da)'*u((2*da/lbd)*sin(azAoA_a(indc2)),M,da))/((nc-2)*(nc-1));
                end
            end
        end
    end

    meanCorrProd_rps(1,m) = mean(diag(Prod_phi1),"all");
    meanCorrProd_mo(1,m) = mean(diag(Prod_phi2),"all");
    meanCorrProd_nr(1,m) = mean(diag(Prod_nris),"all");

    meanCorrProd_rps(2,m) = mean(Prod_phi1 - diag(diag(Prod_phi1)),"all");
    meanCorrProd_mo(2,m) = mean(Prod_phi2 - diag(diag(Prod_phi2)),"all");
    meanCorrProd_nr(2,m) = mean(Prod_nris - diag(diag(Prod_nris)),"all");

    %Compute the matrix that is inverted in the MMSE channel estimation
    denomMatrix_phi1 = (p*tp*(Rue1+sum(Rues_phi1,4)) + eyeM);
    denomMatrix_phi2 = (p*tp*(Rue1+sum(Rues_phi2,4)) + eyeM);
    denomMatrix_nris = (p*tp*(Rue1+sum(Rues,4)) + eyeM);

    %Prepare to store estimation error covariance matrices
    C_MMSE_phi1 = zeros(M,M,tp,nc);
    C_MMSE_phi2 = zeros(M,M,tp,nc);
    C_MMSE_nris = zeros(M,M,tp,nc);

    %Prepare to store MMSE channel estimates
    Hhat_MMSE_phi1 = zeros(M,nbrOfRealizations,tp,nc);
    Hhat_MMSE_phi2 = zeros(M,nbrOfRealizations,tp,nc);
    Hhat_MMSE_nris = zeros(M,nbrOfRealizations,tp,nc);

    for indk=1:tp
        %Estimate channel between BS and UEs
        invQ_phi1 = eyeM / denomMatrix_phi1(:,:,indk);
        invQ_phi2 = eyeM / denomMatrix_phi2(:,:,indk);
        invQ_nris = eyeM / denomMatrix_nris(:,:,indk);
        numdenomMatrix_ue1_phi1 = Rue1(:,:,indk)*invQ_phi1;
        numdenomMatrix_ue1_phi2 = Rue1(:,:,indk)*invQ_phi2;
        numdenomMatrix_ue1_nris = Rue1(:,:,indk)*invQ_nris;
        Hhat_MMSE_phi1(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_phi1*Yp_phi1(:,:,indk);
        Hhat_MMSE_phi2(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_phi2*Yp_phi2(:,:,indk);
        Hhat_MMSE_nris(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_nris*Yp_nris(:,:,indk);

        %Compute corresponding error covariance matrix
        C_MMSE_phi1(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_phi1*Rue1(:,:,indk);
        C_MMSE_phi2(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_phi2*Rue1(:,:,indk);
        C_MMSE_nris(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_nris*Rue1(:,:,indk);

        for indc=2:nc
            %Estimate channel between BS and UEs
            numdenomMatrix_ue2_phi1 = Rues_phi1(:,:,indk,indc-1)*invQ_phi1;
            Hhat_MMSE_phi1(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_phi1*Yp_phi1(:,:,indk);
            numdenomMatrix_ue2_phi2 = Rues_phi2(:,:,indk,indc-1)*invQ_phi2;
            Hhat_MMSE_phi2(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_phi2*Yp_phi2(:,:,indk);
            numdenomMatrix_ue2_nris = Rues(:,:,indk,indc-1)*invQ_nris;
            Hhat_MMSE_nris(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_nris*Yp_nris(:,:,indk);

            %Compute corresponding error covariance matrix
            C_MMSE_phi1(:,:,indk,indc) = Rues_phi1(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_phi1*Rues_phi1(:,:,indk,indc-1);
            C_MMSE_phi2(:,:,indk,indc) = Rues_phi2(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_phi2*Rues_phi2(:,:,indk,indc-1);
            C_MMSE_nris(:,:,indk,indc) = Rues(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_nris*Rues(:,:,indk,indc-1);
        end
    end

    %Store identity matrices of different sizes
    eyeK = eye(K);

    %Compute the pre-log factor assuming only uplink transmission
    prelogFactor = (tau_c-tp)/(tau_c);

    %Compute sum of estimation error covariance matrices for all cells
    C_totM_phi1 = p*sum(sum(C_MMSE_phi1,4),3);
    C_totM_phi2 = p*sum(sum(C_MMSE_phi2,4),3);
    C_totM_nris = p*sum(sum(C_MMSE_nris,4),3);

    %Prepare to store simulation results
    SE_MR_phi1 = zeros(K,nbrOfRealizations);
    SE_MMSE_phi1 = zeros(K,nbrOfRealizations);
    SE_ZF_phi1 = zeros(K,nbrOfRealizations);

    SE_MR_phi2 = zeros(K,nbrOfRealizations);
    SE_MMSE_phi2 = zeros(K,nbrOfRealizations);
    SE_ZF_phi2 = zeros(K,nbrOfRealizations);

    SE_MR_nris = zeros(K,nbrOfRealizations);
    SE_MMSE_nris = zeros(K,nbrOfRealizations);
    SE_ZF_nris = zeros(K,nbrOfRealizations);

    % Go through all channel realizations
    for n = 1:nbrOfRealizations

        %Extract actual channel realizations from all users to BS j
        H_all_phi1 = reshape(H_phi1(:,n,:,:),[M K]);
        H_all_phi2 = reshape(H_phi2(:,n,:,:),[M K]);
        H_all_nris = reshape(H_nris(:,n,:,:),[M K]);

        %Extract channel estimate realizations from all users to BS j
        Hhat_all_phi1 = reshape(Hhat_MMSE_phi1(:,n,:,:),[M K]);
        Hhat_all_phi2 = reshape(Hhat_MMSE_phi2(:,n,:,:),[M K]);
        Hhat_all_nris = reshape(Hhat_MMSE_nris(:,n,:,:),[M K]);

        %Compute MR matrix
        V_MR_phi1 = Hhat_all_phi1;
        V_MR_phi2 = Hhat_all_phi2;
        V_MR_nris = Hhat_all_nris;

        %Compute M-MMSE matrix
        V_MMSE_phi1 = p*(p*(Hhat_all_phi1*Hhat_all_phi1')+C_totM_phi1+eyeM)\V_MR_phi1;
        V_MMSE_phi2 = p*(p*(Hhat_all_phi2*Hhat_all_phi2')+C_totM_phi2+eyeM)\V_MR_phi2;
        V_MMSE_nris = p*(p*(Hhat_all_nris*Hhat_all_nris')+C_totM_nris+eyeM)\V_MR_nris;

        %Compute M-ZF matrix
        V_ZF_phi1 = (Hhat_all_phi1/((Hhat_all_phi1'*Hhat_all_phi1+1e-14*eyeK)))*eyeK;
        V_ZF_phi2 = (Hhat_all_phi2/((Hhat_all_phi2'*Hhat_all_phi2+1e-14*eyeK)))*eyeK;
        V_ZF_nris = (Hhat_all_nris/((Hhat_all_nris'*Hhat_all_nris+1e-14*eyeK)))*eyeK;

        %Go through all users in cell j
        for k = 1:K
            %======== Uplink =============
            %MR combining
            v = V_MR_phi1(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MR_phi1(k,n) = p*abs(v'*Hhat_all_phi1(:,k))^2;
            EfNoise_MR_phi1(k,n) = v'*v;
            EstErr_MR_phi1(k,n) = v'*(C_totM_phi1)*v;
            InterfRP_MR_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1(:,indrp(k,:))).^2) - signal_MR_phi1(k,n);
            InterfNRP_MR_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1).^2) - InterfRP_MR_phi1(k,n) - signal_MR_phi1(k,n);
            interfnoise = EfNoise_MR_phi1(k,n)+EstErr_MR_phi1(k,n)+InterfRP_MR_phi1(k,n)+InterfNRP_MR_phi1(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MR_phi1(k,n) = prelogFactor*real(log2(1+signal_MR_phi1(k,n)/interfnoise));

            v = V_MR_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MR_phi2(k,n) = p*abs(v'*Hhat_all_phi2(:,k))^2;
            EfNoise_MR_phi2(k,n) = v'*v;
            EstErr_MR_phi2(k,n) = v'*(C_totM_phi2)*v;
            InterfRP_MR_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2(:,indrp(k,:))).^2) - signal_MR_phi2(k,n);
            InterfNRP_MR_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2).^2) - InterfRP_MR_phi2(k,n) - signal_MR_phi2(k,n);
            interfnoise = EfNoise_MR_phi2(k,n)+EstErr_MR_phi2(k,n)+InterfRP_MR_phi2(k,n)+InterfNRP_MR_phi2(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MR_phi2(k,n) = prelogFactor*real(log2(1+signal_MR_phi2(k,n)/interfnoise));

            v = V_MR_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MR_nris(k,n) = p*abs(v'*Hhat_all_nris(:,k))^2;
            EfNoise_MR_nris(k,n) = v'*v;
            EstErr_MR_nris(k,n) = v'*(C_totM_nris)*v;
            InterfRP_MR_nris(k,n) = p*sum(abs(v'*Hhat_all_nris(:,indrp(k,:))).^2) - signal_MR_nris(k,n);
            InterfNRP_MR_nris(k,n) = p*sum(abs(v'*Hhat_all_nris).^2) - InterfRP_MR_nris(k,n) - signal_MR_nris(k,n);
            interfnoise = EfNoise_MR_nris(k,n)+EstErr_MR_nris(k,n)+InterfRP_MR_nris(k,n)+InterfNRP_MR_nris(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MR_nris(k,n) = prelogFactor*real(log2(1+signal_MR_nris(k,n)/interfnoise));

            %M-MMSE combining
            v = V_MMSE_phi1(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MMSE_phi1(k,n) = p*abs(v'*Hhat_all_phi1(:,k))^2;
            EfNoise_MMSE_phi1(k,n) = v'*v;
            EstErr_MMSE_phi1(k,n) = v'*(C_totM_phi1)*v;
            InterfRP_MMSE_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1(:,indrp(k,:))).^2) - signal_MMSE_phi1(k,n);
            InterfNRP_MMSE_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1).^2) - InterfRP_MMSE_phi1(k,n) - signal_MMSE_phi1(k,n);
            interfnoise = EfNoise_MMSE_phi1(k,n)+EstErr_MMSE_phi1(k,n)+InterfRP_MMSE_phi1(k,n)+InterfNRP_MMSE_phi1(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MMSE_phi1(k,n) = prelogFactor*real(log2(1+signal_MMSE_phi1(k,n)/interfnoise));

            v = V_MMSE_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MMSE_phi2(k,n) = p*abs(v'*Hhat_all_phi2(:,k))^2;
            EfNoise_MMSE_phi2(k,n) = v'*v;
            EstErr_MMSE_phi2(k,n) = v'*(C_totM_phi2)*v;
            InterfRP_MMSE_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2(:,indrp(k,:))).^2) - signal_MMSE_phi2(k,n);
            InterfNRP_MMSE_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2).^2) - InterfRP_MMSE_phi2(k,n) - signal_MMSE_phi2(k,n);
            interfnoise = EfNoise_MMSE_phi2(k,n)+EstErr_MMSE_phi2(k,n)+InterfRP_MMSE_phi2(k,n)+InterfNRP_MMSE_phi2(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MMSE_phi2(k,n) = prelogFactor*real(log2(1+signal_MMSE_phi2(k,n)/interfnoise));


            v = V_MMSE_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_MMSE_nris(k,n) = p*abs(v'*Hhat_all_nris(:,k))^2;
            EfNoise_MMSE_nris(k,n) = v'*v;
            EstErr_MMSE_nris(k,n) = v'*(C_totM_nris)*v;
            InterfRP_MMSE_nris(k,n) = p*sum(abs(v'*Hhat_all_nris(:,indrp(k,:))).^2) - signal_MMSE_nris(k,n);
            InterfNRP_MMSE_nris(k,n) = p*sum(abs(v'*Hhat_all_nris).^2) - InterfRP_MMSE_nris(k,n) - signal_MMSE_nris(k,n);
            interfnoise = EfNoise_MMSE_nris(k,n)+EstErr_MMSE_nris(k,n)+InterfRP_MMSE_nris(k,n)+InterfNRP_MMSE_nris(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_MMSE_nris(k,n) = prelogFactor*real(log2(1+signal_MMSE_nris(k,n)/interfnoise));

            v = V_ZF_phi1(:,k); %Extract combining vector

            %M-ZF combining
            signal_ZF_phi1(k,n) = p*abs(v'*Hhat_all_phi1(:,k))^2;
            EfNoise_ZF_phi1(k,n) = v'*v;
            EstErr_ZF_phi1(k,n) = v'*(C_totM_phi1)*v;
            InterfRP_ZF_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1(:,indrp(k,:))).^2) - signal_ZF_phi1(k,n);
            InterfNRP_ZF_phi1(k,n) = p*sum(abs(v'*Hhat_all_phi1).^2) - InterfRP_ZF_phi1(k,n) - signal_ZF_phi1(k,n);
            interfnoise = EfNoise_ZF_phi1(k,n)+EstErr_ZF_phi1(k,n)+InterfRP_ZF_phi1(k,n)+InterfNRP_ZF_phi1(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_ZF_phi1(k,n) = prelogFactor*real(log2(1+signal_ZF_phi1(k,n)/interfnoise));

            v = V_ZF_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_ZF_phi2(k,n) = p*abs(v'*Hhat_all_phi2(:,k))^2;
            EfNoise_ZF_phi2(k,n) = v'*v;
            EstErr_ZF_phi2(k,n) = v'*(C_totM_phi2)*v;
            InterfRP_ZF_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2(:,indrp(k,:))).^2) - signal_ZF_phi2(k,n);
            InterfNRP_ZF_phi2(k,n) = p*sum(abs(v'*Hhat_all_phi2).^2) - InterfRP_ZF_phi2(k,n) - signal_ZF_phi2(k,n);
            interfnoise = EfNoise_ZF_phi2(k,n)+EstErr_ZF_phi2(k,n)+InterfRP_ZF_phi2(k,n)+InterfNRP_ZF_phi2(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_ZF_phi2(k,n) = prelogFactor*real(log2(1+signal_ZF_phi2(k,n)/interfnoise));

            v = V_ZF_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal_ZF_nris(k,n) = p*abs(v'*Hhat_all_nris(:,k))^2;
            EfNoise_ZF_nris(k,n) = v'*v;
            EstErr_ZF_nris(k,n) = v'*(C_totM_nris)*v;
            InterfRP_ZF_nris(k,n) = p*sum(abs(v'*Hhat_all_nris(:,indrp(k,:))).^2) - signal_ZF_nris(k,n);
            InterfNRP_ZF_nris(k,n) = p*sum(abs(v'*Hhat_all_nris).^2) - InterfRP_ZF_nris(k,n) - signal_ZF_nris(k,n);
            interfnoise = EfNoise_ZF_nris(k,n)+EstErr_ZF_nris(k,n)+InterfRP_ZF_nris(k,n)+InterfNRP_ZF_nris(k,n);

            %Compute instantaneous achievable SE for one realization
            SE_ZF_nris(k,n) = prelogFactor*real(log2(1+signal_ZF_nris(k,n)/interfnoise));

            %======== Downlink =============

            %MR precoding phi1
            w = V_MR_phi1(:,k)/norm(V_MR_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MR_phi1(k,n) = w'*H_all_phi1(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MR_phi1(indrp_bin,n) = interf_PR_MR_phi1(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MR_phi1(indnrp_bin,n) = interf_NPR_MR_phi1(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indnrp_bin)).^2,[K-nc 1]);

            %MR precoding phi2
            w = V_MR_phi2(:,k)/norm(V_MR_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MR_phi2(k,n) = w'*H_all_phi2(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MR_phi2(indrp_bin,n) = interf_PR_MR_phi2(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MR_phi2(indnrp_bin,n) = interf_NPR_MR_phi2(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indnrp_bin)).^2,[K-nc 1]);

            %MR precoding no RIS
            w = V_MR_nris(:,k)/norm(V_MR_nris(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MR_nris(k,n) = w'*H_all_nris(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MR_nris(indrp_bin,n) = interf_PR_MR_nris(indrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MR_nris(indnrp_bin,n) = interf_NPR_MR_nris(indnrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indnrp_bin)).^2,[K-nc 1]);

            %M-MMSE precoding phi1

            w = V_MMSE_phi1(:,k)/norm(V_MMSE_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MMSE_phi1(k,n) = w'*H_all_phi1(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MMSE_phi1(indrp_bin,n) = interf_PR_MMSE_phi1(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MMSE_phi1(indnrp_bin,n) = interf_NPR_MMSE_phi1(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indnrp_bin)).^2,[K-nc 1]);

            %M-MMSE precoding phi2

            w = V_MMSE_phi2(:,k)/norm(V_MMSE_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MMSE_phi2(k,n) = w'*H_all_phi2(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MMSE_phi2(indrp_bin,n) = interf_PR_MMSE_phi2(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MMSE_phi2(indnrp_bin,n) = interf_NPR_MMSE_phi2(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indnrp_bin)).^2,[K-nc 1]);

            %M-MMSE precoding no RIS

            w = V_MMSE_nris(:,k)/norm(V_MMSE_nris(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_MMSE_nris(k,n) = w'*H_all_nris(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_MMSE_nris(indrp_bin,n) = interf_PR_MMSE_nris(indrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_MMSE_nris(indnrp_bin,n) = interf_NPR_MMSE_nris(indnrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indnrp_bin)).^2,[K-nc 1]);

            %M-ZF precoding phi1

            w = V_ZF_phi1(:,k)/norm(V_ZF_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_ZF_phi1(k,n) = w'*H_all_phi1(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_ZF_phi1(indrp_bin,n) = interf_PR_ZF_phi1(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_ZF_phi1(indnrp_bin,n) = interf_NPR_ZF_phi1(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi1(:,indnrp_bin)).^2,[K-nc 1]);

            %M-ZF precoding phi2

            w = V_ZF_phi2(:,k)/norm(V_ZF_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_ZF_phi2(k,n) = w'*H_all_phi2(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_ZF_phi2(indrp_bin,n) = interf_PR_ZF_phi2(indrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_ZF_phi2(indnrp_bin,n) = interf_NPR_ZF_phi2(indnrp_bin,n) + rho*reshape(abs(w'*H_all_phi2(:,indnrp_bin)).^2,[K-nc 1]);

            %M-MMSE precoding no RIS

            w = V_ZF_nris(:,k)/norm(V_ZF_nris(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signalDL_ZF_nris(k,n) = w'*H_all_nris(:,k);
            indrp_bin = false(K,1);
            indrp_bin(indrp(k,:)) = true;
            indrp_bin(k) = false;
            interf_PR_ZF_nris(indrp_bin,n) = interf_PR_ZF_nris(indrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indrp_bin)).^2,[nc-1 1]);
            indnrp_bin = not(indrp_bin);
            indnrp_bin(k) = false;
            interf_NPR_ZF_nris(indnrp_bin,n) = interf_NPR_ZF_nris(indnrp_bin,n) + rho*reshape(abs(w'*H_all_nris(:,indnrp_bin)).^2,[K-nc 1]);

        end

    end

    %Save UL simulation results when using MMSE estimation
    signal_MR_phi1 = signal_MR_phi1./EfNoise_MR_phi1;
    EstErr_MR_phi1 = EstErr_MR_phi1./EfNoise_MR_phi1;
    InterfRP_MR_phi1 = InterfRP_MR_phi1./EfNoise_MR_phi1;
    InterfNRP_MR_phi1 = InterfNRP_MR_phi1./EfNoise_MR_phi1;
    signal_MR_phi1_avg(1,m) = mean(10*log10(signal_MR_phi1(1:tp,:)),'all');
    signal_MR_phi1_avg(2,m) = mean(10*log10(signal_MR_phi1(tp+1:end,:)),'all');
    signal_MR_phi1_avg(3,m) = mean(10*log10(signal_MR_phi1),'all');
    EstErr_MR_phi1_avg(1,m) = mean(10*log10(EstErr_MR_phi1(1:tp,:)),'all');
    EstErr_MR_phi1_avg(2,m) = mean(10*log10(EstErr_MR_phi1(tp+1:end,:)),'all');
    EstErr_MR_phi1_avg(3,m) = mean(10*log10(EstErr_MR_phi1),'all');
    InterfRP_MR_phi1_avg(1,m) = mean(10*log10(InterfRP_MR_phi1(1:tp,:)),'all');
    InterfRP_MR_phi1_avg(2,m) = mean(10*log10(InterfRP_MR_phi1(tp+1:end,:)),'all');
    InterfRP_MR_phi1_avg(3,m) = mean(10*log10(InterfRP_MR_phi1),'all');
    InterfNRP_MR_phi1_avg(1,m) = mean(10*log10(InterfNRP_MR_phi1(1:tp,:)),'all');
    InterfNRP_MR_phi1_avg(2,m) = mean(10*log10(InterfNRP_MR_phi1(tp+1:end,:)),'all');
    InterfNRP_MR_phi1_avg(3,m) = mean(10*log10(InterfNRP_MR_phi1),'all');
    meanSEperUE_MR(1,m) = mean(SE_MR_phi1(1:tp,:),'all');
    meanSEperUE_MR(2,m) = mean(SE_MR_phi1(tp+1:end,:),'all');
    meanSEperUE_MR(3,m) = mean(SE_MR_phi1,'all');

    signal_MMSE_phi1 = signal_MMSE_phi1./EfNoise_MMSE_phi1;
    EstErr_MMSE_phi1 = EstErr_MMSE_phi1./EfNoise_MMSE_phi1;
    InterfRP_MMSE_phi1 = InterfRP_MMSE_phi1./EfNoise_MMSE_phi1;
    InterfNRP_MMSE_phi1 = InterfNRP_MMSE_phi1./EfNoise_MMSE_phi1;
    signal_MMSE_phi1_avg(1,m) = mean(10*log10(signal_MMSE_phi1(1:tp,:)),'all');
    signal_MMSE_phi1_avg(2,m) = mean(10*log10(signal_MMSE_phi1(tp+1:end,:)),'all');
    signal_MMSE_phi1_avg(3,m) = mean(10*log10(signal_MMSE_phi1),'all');
    EstErr_MMSE_phi1_avg(1,m) = mean(10*log10(EstErr_MMSE_phi1(1:tp,:)),'all');
    EstErr_MMSE_phi1_avg(2,m) = mean(10*log10(EstErr_MMSE_phi1(tp+1:end,:)),'all');
    EstErr_MMSE_phi1_avg(3,m) = mean(10*log10(EstErr_MMSE_phi1),'all');
    InterfRP_MMSE_phi1_avg(1,m) = mean(10*log10(InterfRP_MMSE_phi1(1:tp,:)),'all');
    InterfRP_MMSE_phi1_avg(2,m) = mean(10*log10(InterfRP_MMSE_phi1(tp+1:end,:)),'all');
    InterfRP_MMSE_phi1_avg(3,m) = mean(10*log10(InterfRP_MMSE_phi1),'all');
    InterfNRP_MMSE_phi1_avg(1,m) = mean(10*log10(InterfNRP_MMSE_phi1(1:tp,:)),'all');
    InterfNRP_MMSE_phi1_avg(2,m) = mean(10*log10(InterfNRP_MMSE_phi1(tp+1:end,:)),'all');
    InterfNRP_MMSE_phi1_avg(3,m) = mean(10*log10(InterfNRP_MMSE_phi1),'all');
    meanSEperUE_MMSE(1,m) = mean(SE_MMSE_phi1(1:tp,:),'all');
    meanSEperUE_MMSE(2,m) = mean(SE_MMSE_phi1(tp+1:end,:),'all');
    meanSEperUE_MMSE(3,m) = mean(SE_MMSE_phi1,'all');

    signal_ZF_phi1 = signal_ZF_phi1./EfNoise_ZF_phi1;
    EstErr_ZF_phi1 = EstErr_ZF_phi1./EfNoise_ZF_phi1;
    InterfRP_ZF_phi1 = InterfRP_ZF_phi1./EfNoise_ZF_phi1;
    InterfNRP_ZF_phi1 = InterfNRP_ZF_phi1./EfNoise_ZF_phi1;
    signal_ZF_phi1_avg(1,m) = mean(10*log10(signal_ZF_phi1(1:tp,:)),'all');
    signal_ZF_phi1_avg(2,m) = mean(10*log10(signal_ZF_phi1(tp+1:end,:)),'all');
    signal_ZF_phi1_avg(3,m) = mean(10*log10(signal_ZF_phi1),'all');
    EstErr_ZF_phi1_avg(1,m) = mean(10*log10(EstErr_ZF_phi1(1:tp,:)),'all');
    EstErr_ZF_phi1_avg(2,m) = mean(10*log10(EstErr_ZF_phi1(tp+1:end,:)),'all');
    EstErr_ZF_phi1_avg(3,m) = mean(10*log10(EstErr_ZF_phi1),'all');
    InterfRP_ZF_phi1_avg(1,m) = mean(10*log10(InterfRP_ZF_phi1(1:tp,:)),'all');
    InterfRP_ZF_phi1_avg(2,m) = mean(10*log10(InterfRP_ZF_phi1(tp+1:end,:)),'all');
    InterfRP_ZF_phi1_avg(3,m) = mean(10*log10(InterfRP_ZF_phi1),'all');
    InterfNRP_ZF_phi1_avg(1,m) = mean(10*log10(InterfNRP_ZF_phi1(1:tp,:)),'all');
    InterfNRP_ZF_phi1_avg(2,m) = mean(10*log10(InterfNRP_ZF_phi1(tp+1:end,:)),'all');
    InterfNRP_ZF_phi1_avg(3,m) = mean(10*log10(InterfNRP_ZF_phi1),'all');
    meanSEperUE_ZF(1,m) = mean(SE_ZF_phi1(1:tp,:),'all');
    meanSEperUE_ZF(2,m) = mean(SE_ZF_phi1(tp+1:end,:),'all');
    meanSEperUE_ZF(3,m) = mean(SE_ZF_phi1,'all');

    signal_MR_phi2 = signal_MR_phi2./EfNoise_MR_phi2;
    EstErr_MR_phi2 = EstErr_MR_phi2./EfNoise_MR_phi2;
    InterfRP_MR_phi2 = InterfRP_MR_phi2./EfNoise_MR_phi2;
    InterfNRP_MR_phi2 = InterfNRP_MR_phi2./EfNoise_MR_phi2;
    signal_MR_phi2_avg(1,m) = mean(10*log10(signal_MR_phi2(1:tp,:)),'all');
    signal_MR_phi2_avg(2,m) = mean(10*log10(signal_MR_phi2(tp+1:end,:)),'all');
    signal_MR_phi2_avg(3,m) = mean(10*log10(signal_MR_phi2),'all');
    EstErr_MR_phi2_avg(1,m) = mean(10*log10(EstErr_MR_phi2(1:tp,:)),'all');
    EstErr_MR_phi2_avg(2,m) = mean(10*log10(EstErr_MR_phi2(tp+1:end,:)),'all');
    EstErr_MR_phi2_avg(3,m) = mean(10*log10(EstErr_MR_phi2),'all');
    InterfRP_MR_phi2_avg(1,m) = mean(10*log10(InterfRP_MR_phi2(1:tp,:)),'all');
    InterfRP_MR_phi2_avg(2,m) = mean(10*log10(InterfRP_MR_phi2(tp+1:end,:)),'all');
    InterfRP_MR_phi2_avg(3,m) = mean(10*log10(InterfRP_MR_phi2),'all');
    InterfNRP_MR_phi2_avg(1,m) = mean(10*log10(InterfNRP_MR_phi2(1:tp,:)),'all');
    InterfNRP_MR_phi2_avg(2,m) = mean(10*log10(InterfNRP_MR_phi2(tp+1:end,:)),'all');
    InterfNRP_MR_phi2_avg(3,m) = mean(10*log10(InterfNRP_MR_phi2),'all');
    meanSEperUE_MR_mo(1,m) = mean(SE_MR_phi2(1:tp,:),'all');
    meanSEperUE_MR_mo(2,m) = mean(SE_MR_phi2(tp+1:end,:),'all');
    meanSEperUE_MR_mo(3,m) = mean(SE_MR_phi2,'all');

    signal_MMSE_phi2 = signal_MMSE_phi2./EfNoise_MMSE_phi2;
    EstErr_MMSE_phi2 = EstErr_MMSE_phi2./EfNoise_MMSE_phi2;
    InterfRP_MMSE_phi2 = InterfRP_MMSE_phi2./EfNoise_MMSE_phi2;
    InterfNRP_MMSE_phi2 = InterfNRP_MMSE_phi2./EfNoise_MMSE_phi2;
    signal_MMSE_phi2_avg(1,m) = mean(10*log10(signal_MMSE_phi2(1:tp,:)),'all');
    signal_MMSE_phi2_avg(2,m) = mean(10*log10(signal_MMSE_phi2(tp+1:end,:)),'all');
    signal_MMSE_phi2_avg(3,m) = mean(10*log10(signal_MMSE_phi2),'all');
    EstErr_MMSE_phi2_avg(1,m) = mean(10*log10(EstErr_MMSE_phi2(1:tp,:)),'all');
    EstErr_MMSE_phi2_avg(2,m) = mean(10*log10(EstErr_MMSE_phi2(tp+1:end,:)),'all');
    EstErr_MMSE_phi2_avg(3,m) = mean(10*log10(EstErr_MMSE_phi2),'all');
    InterfRP_MMSE_phi2_avg(1,m) = mean(10*log10(InterfRP_MMSE_phi2(1:tp,:)),'all');
    InterfRP_MMSE_phi2_avg(2,m) = mean(10*log10(InterfRP_MMSE_phi2(tp+1:end,:)),'all');
    InterfRP_MMSE_phi2_avg(3,m) = mean(10*log10(InterfRP_MMSE_phi2),'all');
    InterfNRP_MMSE_phi2_avg(1,m) = mean(10*log10(InterfNRP_MMSE_phi2(1:tp,:)),'all');
    InterfNRP_MMSE_phi2_avg(2,m) = mean(10*log10(InterfNRP_MMSE_phi2(tp+1:end,:)),'all');
    InterfNRP_MMSE_phi2_avg(3,m) = mean(10*log10(InterfNRP_MMSE_phi2),'all');
    meanSEperUE_MMSE_mo(1,m) = mean(SE_MMSE_phi2(1:tp,:),'all');
    meanSEperUE_MMSE_mo(2,m) = mean(SE_MMSE_phi2(tp+1:end,:),'all');
    meanSEperUE_MMSE_mo(3,m) = mean(SE_MMSE_phi2,'all');

    signal_ZF_phi2 = signal_ZF_phi2./EfNoise_ZF_phi2;
    EstErr_ZF_phi2 = EstErr_ZF_phi2./EfNoise_ZF_phi2;
    InterfRP_ZF_phi2 = InterfRP_ZF_phi2./EfNoise_ZF_phi2;
    InterfNRP_ZF_phi2 = InterfNRP_ZF_phi2./EfNoise_ZF_phi2;
    signal_ZF_phi2_avg(1,m) = mean(10*log10(signal_ZF_phi2(1:tp,:)),'all');
    signal_ZF_phi2_avg(2,m) = mean(10*log10(signal_ZF_phi2(tp+1:end,:)),'all');
    signal_ZF_phi2_avg(3,m) = mean(10*log10(signal_ZF_phi2),'all');
    EstErr_ZF_phi2_avg(1,m) = mean(10*log10(EstErr_ZF_phi2(1:tp,:)),'all');
    EstErr_ZF_phi2_avg(2,m) = mean(10*log10(EstErr_ZF_phi2(tp+1:end,:)),'all');
    EstErr_ZF_phi2_avg(3,m) = mean(10*log10(EstErr_ZF_phi2),'all');
    InterfRP_ZF_phi2_avg(1,m) = mean(10*log10(InterfRP_ZF_phi2(1:tp,:)),'all');
    InterfRP_ZF_phi2_avg(2,m) = mean(10*log10(InterfRP_ZF_phi2(tp+1:end,:)),'all');
    InterfRP_ZF_phi2_avg(3,m) = mean(10*log10(InterfRP_ZF_phi2),'all');
    InterfNRP_ZF_phi2_avg(1,m) = mean(10*log10(InterfNRP_ZF_phi2(1:tp,:)),'all');
    InterfNRP_ZF_phi2_avg(2,m) = mean(10*log10(InterfNRP_ZF_phi2(tp+1:end,:)),'all');
    InterfNRP_ZF_phi2_avg(3,m) = mean(10*log10(InterfNRP_ZF_phi2),'all');
    meanSEperUE_ZF_mo(1,m) = mean(SE_ZF_phi2(1:tp,:),'all');
    meanSEperUE_ZF_mo(2,m) = mean(SE_ZF_phi2(tp+1:end,:),'all');
    meanSEperUE_ZF_mo(3,m) = mean(SE_ZF_phi2,'all');

    signal_MR_nris = signal_MR_nris./EfNoise_MR_nris;
    EstErr_MR_nris = EstErr_MR_nris./EfNoise_MR_nris;
    InterfRP_MR_nris = InterfRP_MR_nris./EfNoise_MR_nris;
    InterfNRP_MR_nris = InterfNRP_MR_nris./EfNoise_MR_nris;
    signal_MR_nris_avg(1,m) = mean(10*log10(signal_MR_nris(1:tp,:)),'all');
    signal_MR_nris_avg(2,m) = mean(10*log10(signal_MR_nris(tp+1:end,:)),'all');
    signal_MR_nris_avg(3,m) = mean(10*log10(signal_MR_nris),'all');
    EstErr_MR_nris_avg(1,m) = mean(10*log10(EstErr_MR_nris(1:tp,:)),'all');
    EstErr_MR_nris_avg(2,m) = mean(10*log10(EstErr_MR_nris(tp+1:end,:)),'all');
    EstErr_MR_nris_avg(3,m) = mean(10*log10(EstErr_MR_nris),'all');
    InterfRP_MR_nris_avg(1,m) = mean(10*log10(InterfRP_MR_nris(1:tp,:)),'all');
    InterfRP_MR_nris_avg(2,m) = mean(10*log10(InterfRP_MR_nris(tp+1:end,:)),'all');
    InterfRP_MR_nris_avg(3,m) = mean(10*log10(InterfRP_MR_nris),'all');
    InterfNRP_MR_nris_avg(1,m) = mean(10*log10(InterfNRP_MR_nris(1:tp,:)),'all');
    InterfNRP_MR_nris_avg(2,m) = mean(10*log10(InterfNRP_MR_nris(tp+1:end,:)),'all');
    InterfNRP_MR_nris_avg(3,m) = mean(10*log10(InterfNRP_MR_nris),'all');
    meanSEperUE_MR_nr(1,m) = mean(SE_MR_nris(1:tp,:),'all');
    meanSEperUE_MR_nr(2,m) = mean(SE_MR_nris(tp+1:end,:),'all');
    meanSEperUE_MR_nr(3,m) = mean(SE_MR_nris,'all');

    signal_MMSE_nris = signal_MMSE_nris./EfNoise_MMSE_nris;
    EstErr_MMSE_nris = EstErr_MMSE_nris./EfNoise_MMSE_nris;
    InterfRP_MMSE_nris = InterfRP_MMSE_nris./EfNoise_MMSE_nris;
    InterfNRP_MMSE_nris = InterfNRP_MMSE_nris./EfNoise_MMSE_nris;
    signal_MMSE_nris_avg(1,m) = mean(10*log10(signal_MMSE_nris(1:tp,:)),'all');
    signal_MMSE_nris_avg(2,m) = mean(10*log10(signal_MMSE_nris(tp+1:end,:)),'all');
    signal_MMSE_nris_avg(3,m) = mean(10*log10(signal_MMSE_nris),'all');
    EstErr_MMSE_nris_avg(1,m) = mean(10*log10(EstErr_MMSE_nris(1:tp,:)),'all');
    EstErr_MMSE_nris_avg(2,m) = mean(10*log10(EstErr_MMSE_nris(tp+1:end,:)),'all');
    EstErr_MMSE_nris_avg(3,m) = mean(10*log10(EstErr_MMSE_nris),'all');
    InterfRP_MMSE_nris_avg(1,m) = mean(10*log10(InterfRP_MMSE_nris(1:tp,:)),'all');
    InterfRP_MMSE_nris_avg(2,m) = mean(10*log10(InterfRP_MMSE_nris(tp+1:end,:)),'all');
    InterfRP_MMSE_nris_avg(3,m) = mean(10*log10(InterfRP_MMSE_nris),'all');
    InterfNRP_MMSE_nris_avg(1,m) = mean(10*log10(InterfNRP_MMSE_nris(1:tp,:)),'all');
    InterfNRP_MMSE_nris_avg(2,m) = mean(10*log10(InterfNRP_MMSE_nris(tp+1:end,:)),'all');
    InterfNRP_MMSE_nris_avg(3,m) = mean(10*log10(InterfNRP_MMSE_nris),'all');
    meanSEperUE_MMSE_nr(1,m) = mean(SE_MMSE_nris(1:tp,:),'all');
    meanSEperUE_MMSE_nr(2,m) = mean(SE_MMSE_nris(tp+1:end,:),'all');
    meanSEperUE_MMSE_nr(3,m) = mean(SE_MMSE_nris,'all');

    signal_ZF_nris = signal_ZF_nris./EfNoise_ZF_nris;
    EstErr_ZF_nris = EstErr_ZF_nris./EfNoise_ZF_nris;
    InterfRP_ZF_nris = InterfRP_ZF_nris./EfNoise_ZF_nris;
    InterfNRP_ZF_nris = InterfNRP_ZF_nris./EfNoise_ZF_nris;
    signal_ZF_nris_avg(1,m) = mean(10*log10(signal_ZF_nris(1:tp,:)),'all');
    signal_ZF_nris_avg(2,m) = mean(10*log10(signal_ZF_nris(tp+1:end,:)),'all');
    signal_ZF_nris_avg(3,m) = mean(10*log10(signal_ZF_nris),'all');
    EstErr_ZF_nris_avg(1,m) = mean(10*log10(EstErr_ZF_nris(1:tp,:)),'all');
    EstErr_ZF_nris_avg(2,m) = mean(10*log10(EstErr_ZF_nris(tp+1:end,:)),'all');
    EstErr_ZF_nris_avg(3,m) = mean(10*log10(EstErr_ZF_nris),'all');
    InterfRP_ZF_nris_avg(1,m) = mean(10*log10(InterfRP_ZF_nris(1:tp,:)),'all');
    InterfRP_ZF_nris_avg(2,m) = mean(10*log10(InterfRP_ZF_nris(tp+1:end,:)),'all');
    InterfRP_ZF_nris_avg(3,m) = mean(10*log10(InterfRP_ZF_nris),'all');
    InterfNRP_ZF_nris_avg(1,m) = mean(10*log10(InterfNRP_ZF_nris(1:tp,:)),'all');
    InterfNRP_ZF_nris_avg(2,m) = mean(10*log10(InterfNRP_ZF_nris(tp+1:end,:)),'all');
    InterfNRP_ZF_nris_avg(3,m) = mean(10*log10(InterfNRP_ZF_nris),'all');
    meanSEperUE_ZF_nr(1,m) = mean(SE_ZF_nris(1:tp,:),'all');
    meanSEperUE_ZF_nr(2,m) = mean(SE_ZF_nris(tp+1:end,:),'all');
    meanSEperUE_ZF_nr(3,m) = mean(SE_ZF_nris,'all');

    %Save DL simulation results when using MMSE estimation

    %Compute SE with MR and phi2
    desSign_MR_DL_phi1_avg = rho*abs(mean(signalDL_MR_phi1,2)).^2;
    selfInt_MR_DL_phi1_avg = rho*mean(abs(signalDL_MR_phi1).^2,2) - desSign_MR_DL_phi1_avg;
    IntPR_MR_DL_phi1_avg = mean(interf_PR_MR_phi1,2);
    IntNPR_MR_DL_phi1_avg = mean(interf_NPR_MR_phi1,2);
    meanSEperUE_MR_DL_avg = prelogFactor*real(log2(1+ desSign_MR_DL_phi1_avg./ (selfInt_MR_DL_phi1_avg + IntPR_MR_DL_phi1_avg + IntNPR_MR_DL_phi1_avg + 1)));

    % desSign_MR_DL_phi1(1,m) = mean(10*log10(desSign_MR_DL_phi1_avg(1:tp,:)),'all');
    % desSign_MR_DL_phi1(2,m) = mean(10*log10(desSign_MR_DL_phi1_avg(tp+1:end,:)),'all');
    % desSign_MR_DL_phi1(3,m) = mean(10*log10(desSign_MR_DL_phi1_avg),'all');
    % selfInt_MR_DL_phi1(1,m) = mean(10*log10(selfInt_MR_DL_phi1_avg(1:tp,:)),'all');
    % selfInt_MR_DL_phi1(2,m) = mean(10*log10(selfInt_MR_DL_phi1_avg(tp+1:end,:)),'all');
    % selfInt_MR_DL_phi1(3,m) = mean(10*log10(selfInt_MR_DL_phi1_avg),'all');
    % IntPR_MR_DL_phi1(1,m) = mean(10*log10(IntPR_MR_DL_phi1_avg(1:tp,:)),'all');
    % IntPR_MR_DL_phi1(2,m) = mean(10*log10(IntPR_MR_DL_phi1_avg(tp+1:end,:)),'all');
    % IntPR_MR_DL_phi1(3,m) = mean(10*log10(IntPR_MR_DL_phi1_avg),'all');
    % IntNPR_MR_DL_phi1(1,m) = mean(10*log10(IntNPR_MR_DL_phi1_avg(1:tp,:)),'all');
    % IntNPR_MR_DL_phi1(2,m) = mean(10*log10(IntNPR_MR_DL_phi1_avg(tp+1:end,:)),'all');
    % IntNPR_MR_DL_phi1(3,m) = mean(10*log10(IntNPR_MR_DL_phi1_avg),'all');
    meanSEperUE_MR_DL(1,m) = mean(meanSEperUE_MR_DL_avg(1:tp,:),'all');
    meanSEperUE_MR_DL(2,m) = mean(meanSEperUE_MR_DL_avg(tp+1:end,:),'all');
    meanSEperUE_MR_DL(3,m) = mean(meanSEperUE_MR_DL_avg,'all');

    %Compute SE with MR and phi2
    desSign_MR_DL_phi2_avg = rho*abs(mean(signalDL_MR_phi2,2)).^2;
    selfInt_MR_DL_phi2_avg = rho*mean(abs(signalDL_MR_phi2).^2,2) - desSign_MR_DL_phi2_avg;
    IntPR_MR_DL_phi2_avg = mean(interf_PR_MR_phi2,2);
    IntNPR_MR_DL_phi2_avg = mean(interf_NPR_MR_phi2,2);
    meanSEperUE_MR_DL_mo_avg = prelogFactor*real(log2(1+ desSign_MR_DL_phi2_avg./ (selfInt_MR_DL_phi2_avg + IntPR_MR_DL_phi2_avg + IntNPR_MR_DL_phi2_avg + 1)));

    % desSign_MR_DL_phi2(1,m) = mean(10*log10(desSign_MR_DL_phi2_avg(1:tp,:)),'all');
    % desSign_MR_DL_phi2(2,m) = mean(10*log10(desSign_MR_DL_phi2_avg(tp+1:end,:)),'all');
    % desSign_MR_DL_phi2(3,m) = mean(10*log10(desSign_MR_DL_phi2_avg),'all');
    % selfInt_MR_DL_phi2(1,m) = mean(10*log10(selfInt_MR_DL_phi2_avg(1:tp,:)),'all');
    % selfInt_MR_DL_phi2(2,m) = mean(10*log10(selfInt_MR_DL_phi2_avg(tp+1:end,:)),'all');
    % selfInt_MR_DL_phi2(3,m) = mean(10*log10(selfInt_MR_DL_phi2_avg),'all');
    % IntPR_MR_DL_phi2(1,m) = mean(10*log10(IntPR_MR_DL_phi2_avg(1:tp,:)),'all');
    % IntPR_MR_DL_phi2(2,m) = mean(10*log10(IntPR_MR_DL_phi2_avg(tp+1:end,:)),'all');
    % IntPR_MR_DL_phi2(3,m) = mean(10*log10(IntPR_MR_DL_phi2_avg),'all');
    % IntNPR_MR_DL_phi2(1,m) = mean(10*log10(IntNPR_MR_DL_phi2_avg(1:tp,:)),'all');
    % IntNPR_MR_DL_phi2(2,m) = mean(10*log10(IntNPR_MR_DL_phi2_avg(tp+1:end,:)),'all');
    % IntNPR_MR_DL_phi2(3,m) = mean(10*log10(IntNPR_MR_DL_phi2_avg),'all');
    meanSEperUE_MR_mo_DL(1,m) = mean(meanSEperUE_MR_DL_mo_avg(1:tp,:),'all');
    meanSEperUE_MR_mo_DL(2,m) = mean(meanSEperUE_MR_DL_mo_avg(tp+1:end,:),'all');
    meanSEperUE_MR_mo_DL(3,m) = mean(meanSEperUE_MR_DL_mo_avg,'all');

    %Compute SE with MR and no RIS
    desSign_MR_DL_nris_avg = rho*abs(mean(signalDL_MR_nris,2)).^2;
    selfInt_MR_DL_nris_avg = rho*mean(abs(signalDL_MR_nris).^2,2) - desSign_MR_DL_nris_avg;
    IntPR_MR_DL_nris_avg = mean(interf_PR_MR_nris,2);
    IntNPR_MR_DL_nris_avg = mean(interf_NPR_MR_nris,2);
    meanSEperUE_MR_DL_nr_avg = prelogFactor*real(log2(1+ desSign_MR_DL_nris_avg./ (selfInt_MR_DL_nris_avg + IntPR_MR_DL_nris_avg + IntNPR_MR_DL_nris_avg + 1)));

    % desSign_MR_DL_nris(1,m) = mean(10*log10(desSign_MR_DL_nris_avg(1:tp,:)),'all');
    % desSign_MR_DL_nris(2,m) = mean(10*log10(desSign_MR_DL_nris_avg(tp+1:end,:)),'all');
    % desSign_MR_DL_nris(3,m) = mean(10*log10(desSign_MR_DL_nris_avg),'all');
    % selfInt_MR_DL_nris(1,m) = mean(10*log10(selfInt_MR_DL_nris_avg(1:tp,:)),'all');
    % selfInt_MR_DL_nris(2,m) = mean(10*log10(selfInt_MR_DL_nris_avg(tp+1:end,:)),'all');
    % selfInt_MR_DL_nris(3,m) = mean(10*log10(selfInt_MR_DL_nris_avg),'all');
    % IntPR_MR_DL_nris(1,m) = mean(10*log10(IntPR_MR_DL_nris_avg(1:tp,:)),'all');
    % IntPR_MR_DL_nris(2,m) = mean(10*log10(IntPR_MR_DL_nris_avg(tp+1:end,:)),'all');
    % IntPR_MR_DL_nris(3,m) = mean(10*log10(IntPR_MR_DL_nris_avg),'all');
    % IntNPR_MR_DL_nris(1,m) = mean(10*log10(IntNPR_MR_DL_nris_avg(1:tp,:)),'all');
    % IntNPR_MR_DL_nris(2,m) = mean(10*log10(IntNPR_MR_DL_nris_avg(tp+1:end,:)),'all');
    % IntNPR_MR_DL_nris(3,m) = mean(10*log10(IntNPR_MR_DL_nris_avg),'all');
    meanSEperUE_MR_nr_DL(1,m) = mean(meanSEperUE_MR_DL_nr_avg(1:tp,:),'all');
    meanSEperUE_MR_nr_DL(2,m) = mean(meanSEperUE_MR_DL_nr_avg(tp+1:end,:),'all');
    meanSEperUE_MR_nr_DL(3,m) = mean(meanSEperUE_MR_DL_nr_avg,'all'); 

    %Compute SE with M-MMSE and phi1
    desSign_MMSE_DL_phi1_avg = rho*abs(mean(signalDL_MMSE_phi1,2)).^2;
    selfInt_MMSE_DL_phi1_avg = rho*mean(abs(signalDL_MMSE_phi1).^2,2) - desSign_MMSE_DL_phi1_avg;
    IntPR_MMSE_DL_phi1_avg = mean(interf_PR_MMSE_phi1,2);
    IntNPR_MMSE_DL_phi1_avg = mean(interf_NPR_MMSE_phi1,2);
    meanSEperUE_MMSE_DL_avg = prelogFactor*real(log2(1+ desSign_MMSE_DL_phi1_avg./ (selfInt_MMSE_DL_phi1_avg + IntPR_MMSE_DL_phi1_avg + IntNPR_MMSE_DL_phi1_avg + 1)));

    % desSign_MMSE_DL_phi1(1,m) = mean(10*log10(desSign_MMSE_DL_phi1_avg(1:tp,:)),'all');
    % desSign_MMSE_DL_phi1(2,m) = mean(10*log10(desSign_MMSE_DL_phi1_avg(tp+1:end,:)),'all');
    % desSign_MMSE_DL_phi1(3,m) = mean(10*log10(desSign_MMSE_DL_phi1_avg),'all');
    % selfInt_MMSE_DL_phi1(1,m) = mean(10*log10(selfInt_MMSE_DL_phi1_avg(1:tp,:)),'all');
    % selfInt_MMSE_DL_phi1(2,m) = mean(10*log10(selfInt_MMSE_DL_phi1_avg(tp+1:end,:)),'all');
    % selfInt_MMSE_DL_phi1(3,m) = mean(10*log10(selfInt_MMSE_DL_phi1_avg),'all');
    % IntPR_MMSE_DL_phi1(1,m) = mean(10*log10(IntPR_MMSE_DL_phi1_avg(1:tp,:)),'all');
    % IntPR_MMSE_DL_phi1(2,m) = mean(10*log10(IntPR_MMSE_DL_phi1_avg(tp+1:end,:)),'all');
    % IntPR_MMSE_DL_phi1(3,m) = mean(10*log10(IntPR_MMSE_DL_phi1_avg),'all');
    % IntNPR_MMSE_DL_phi1(1,m) = mean(10*log10(IntNPR_MMSE_DL_phi1_avg(1:tp,:)),'all');
    % IntNPR_MMSE_DL_phi1(2,m) = mean(10*log10(IntNPR_MMSE_DL_phi1_avg(tp+1:end,:)),'all');
    % IntNPR_MMSE_DL_phi1(3,m) = mean(10*log10(IntNPR_MMSE_DL_phi1_avg),'all');
    meanSEperUE_MMSE_DL(1,m) = mean(meanSEperUE_MMSE_DL_avg(1:tp,:),'all');
    meanSEperUE_MMSE_DL(2,m) = mean(meanSEperUE_MMSE_DL_avg(tp+1:end,:),'all');
    meanSEperUE_MMSE_DL(3,m) = mean(meanSEperUE_MMSE_DL_avg,'all');

    %Compute SE with MMSE and phi2
    desSign_MMSE_DL_phi2_avg = rho*abs(mean(signalDL_MMSE_phi2,2)).^2;
    selfInt_MMSE_DL_phi2_avg = rho*mean(abs(signalDL_MMSE_phi2).^2,2) - desSign_MMSE_DL_phi2_avg;
    IntPR_MMSE_DL_phi2_avg = mean(interf_PR_MMSE_phi2,2);
    IntNPR_MMSE_DL_phi2_avg = mean(interf_NPR_MMSE_phi2,2);
    meanSEperUE_MMSE_DL_mo_avg = prelogFactor*real(log2(1+ desSign_MMSE_DL_phi2_avg./ (selfInt_MMSE_DL_phi2_avg + IntPR_MMSE_DL_phi2_avg + IntNPR_MMSE_DL_phi2_avg + 1)));

    % desSign_MMSE_DL_phi2(1,m) = mean(10*log10(desSign_MMSE_DL_phi2_avg(1:tp,:)),'all');
    % desSign_MMSE_DL_phi2(2,m) = mean(10*log10(desSign_MMSE_DL_phi2_avg(tp+1:end,:)),'all');
    % desSign_MMSE_DL_phi2(3,m) = mean(10*log10(desSign_MMSE_DL_phi2_avg),'all');
    % selfInt_MMSE_DL_phi2(1,m) = mean(10*log10(selfInt_MMSE_DL_phi2_avg(1:tp,:)),'all');
    % selfInt_MMSE_DL_phi2(2,m) = mean(10*log10(selfInt_MMSE_DL_phi2_avg(tp+1:end,:)),'all');
    % selfInt_MMSE_DL_phi2(3,m) = mean(10*log10(selfInt_MMSE_DL_phi2_avg),'all');
    % IntPR_MMSE_DL_phi2(1,m) = mean(10*log10(IntPR_MMSE_DL_phi2_avg(1:tp,:)),'all');
    % IntPR_MMSE_DL_phi2(2,m) = mean(10*log10(IntPR_MMSE_DL_phi2_avg(tp+1:end,:)),'all');
    % IntPR_MMSE_DL_phi2(3,m) = mean(10*log10(IntPR_MMSE_DL_phi2_avg),'all');
    % IntNPR_MMSE_DL_phi2(1,m) = mean(10*log10(IntNPR_MMSE_DL_phi2_avg(1:tp,:)),'all');
    % IntNPR_MMSE_DL_phi2(2,m) = mean(10*log10(IntNPR_MMSE_DL_phi2_avg(tp+1:end,:)),'all');
    % IntNPR_MMSE_DL_phi2(3,m) = mean(10*log10(IntNPR_MMSE_DL_phi2_avg),'all');
    meanSEperUE_MMSE_mo_DL(1,m) = mean(meanSEperUE_MMSE_DL_mo_avg(1:tp,:),'all');
    meanSEperUE_MMSE_mo_DL(2,m) = mean(meanSEperUE_MMSE_DL_mo_avg(tp+1:end,:),'all');
    meanSEperUE_MMSE_mo_DL(3,m) = mean(meanSEperUE_MMSE_DL_mo_avg,'all');

    %Compute SE with M-MMSE and no RIS
    desSign_MMSE_DL_nris_avg = rho*abs(mean(signalDL_MMSE_nris,2)).^2;
    selfInt_MMSE_DL_nris_avg = rho*mean(abs(signalDL_MMSE_nris).^2,2) - desSign_MMSE_DL_nris_avg;
    IntPR_MMSE_DL_nris_avg = mean(interf_PR_MMSE_nris,2);
    IntNPR_MMSE_DL_nris_avg = mean(interf_NPR_MMSE_nris,2);
    meanSEperUE_MMSE_DL_nr_avg = prelogFactor*real(log2(1+ desSign_MMSE_DL_nris_avg./ (selfInt_MMSE_DL_nris_avg + IntPR_MMSE_DL_nris_avg + IntNPR_MMSE_DL_nris_avg + 1)));

    % desSign_MMSE_DL_nris(1,m) = mean(10*log10(desSign_MMSE_DL_nris_avg(1:tp,:)),'all');
    % desSign_MMSE_DL_nris(2,m) = mean(10*log10(desSign_MMSE_DL_nris_avg(tp+1:end,:)),'all');
    % desSign_MMSE_DL_nris(3,m) = mean(10*log10(desSign_MMSE_DL_nris_avg),'all');
    % selfInt_MMSE_DL_nris(1,m) = mean(10*log10(selfInt_MMSE_DL_nris_avg(1:tp,:)),'all');
    % selfInt_MMSE_DL_nris(2,m) = mean(10*log10(selfInt_MMSE_DL_nris_avg(tp+1:end,:)),'all');
    % selfInt_MMSE_DL_nris(3,m) = mean(10*log10(selfInt_MMSE_DL_nris_avg),'all');
    % IntPR_MMSE_DL_nris(1,m) = mean(10*log10(IntPR_MMSE_DL_nris_avg(1:tp,:)),'all');
    % IntPR_MMSE_DL_nris(2,m) = mean(10*log10(IntPR_MMSE_DL_nris_avg(tp+1:end,:)),'all');
    % IntPR_MMSE_DL_nris(3,m) = mean(10*log10(IntPR_MMSE_DL_nris_avg),'all');
    % IntNPR_MMSE_DL_nris(1,m) = mean(10*log10(IntNPR_MMSE_DL_nris_avg(1:tp,:)),'all');
    % IntNPR_MMSE_DL_nris(2,m) = mean(10*log10(IntNPR_MMSE_DL_nris_avg(tp+1:end,:)),'all');
    % IntNPR_MMSE_DL_nris(3,m) = mean(10*log10(IntNPR_MMSE_DL_nris_avg),'all');
    meanSEperUE_MMSE_nr_DL(1,m) = mean(meanSEperUE_MMSE_DL_nr_avg(1:tp,:),'all');
    meanSEperUE_MMSE_nr_DL(2,m) = mean(meanSEperUE_MMSE_DL_nr_avg(tp+1:end,:),'all');
    meanSEperUE_MMSE_nr_DL(3,m) = mean(meanSEperUE_MMSE_DL_nr_avg,'all'); 

    %Compute SE with M-ZF and phi1
    desSign_ZF_DL_phi1_avg = rho*abs(mean(signalDL_ZF_phi1,2)).^2;
    selfInt_ZF_DL_phi1_avg = rho*mean(abs(signalDL_ZF_phi1).^2,2) - desSign_ZF_DL_phi1_avg;
    IntPR_ZF_DL_phi1_avg = mean(interf_PR_ZF_phi1,2);
    IntNPR_ZF_DL_phi1_avg = mean(interf_NPR_ZF_phi1,2);
    meanSEperUE_ZF_DL_avg = prelogFactor*real(log2(1+ desSign_ZF_DL_phi1_avg./ (selfInt_ZF_DL_phi1_avg + IntPR_ZF_DL_phi1_avg + IntNPR_ZF_DL_phi1_avg + 1)));

    % desSign_ZF_DL_phi1(1,m) = mean(10*log10(desSign_ZF_DL_phi1_avg(1:tp,:)),'all');
    % desSign_ZF_DL_phi1(2,m) = mean(10*log10(desSign_ZF_DL_phi1_avg(tp+1:end,:)),'all');
    % desSign_ZF_DL_phi1(3,m) = mean(10*log10(desSign_ZF_DL_phi1_avg),'all');
    % selfInt_ZF_DL_phi1(1,m) = mean(10*log10(selfInt_ZF_DL_phi1_avg(1:tp,:)),'all');
    % selfInt_ZF_DL_phi1(2,m) = mean(10*log10(selfInt_ZF_DL_phi1_avg(tp+1:end,:)),'all');
    % selfInt_ZF_DL_phi1(3,m) = mean(10*log10(selfInt_ZF_DL_phi1_avg),'all');
    % IntPR_ZF_DL_phi1(1,m) = mean(10*log10(IntPR_ZF_DL_phi1_avg(1:tp,:)),'all');
    % IntPR_ZF_DL_phi1(2,m) = mean(10*log10(IntPR_ZF_DL_phi1_avg(tp+1:end,:)),'all');
    % IntPR_ZF_DL_phi1(3,m) = mean(10*log10(IntPR_ZF_DL_phi1_avg),'all');
    % IntNPR_ZF_DL_phi1(1,m) = mean(10*log10(IntNPR_ZF_DL_phi1_avg(1:tp,:)),'all');
    % IntNPR_ZF_DL_phi1(2,m) = mean(10*log10(IntNPR_ZF_DL_phi1_avg(tp+1:end,:)),'all');
    % IntNPR_ZF_DL_phi1(3,m) = mean(10*log10(IntNPR_ZF_DL_phi1_avg),'all');
    meanSEperUE_ZF_DL(1,m) = mean(meanSEperUE_ZF_DL_avg(1:tp,:),'all');
    meanSEperUE_ZF_DL(2,m) = mean(meanSEperUE_ZF_DL_avg(tp+1:end,:),'all');
    meanSEperUE_ZF_DL(3,m) = mean(meanSEperUE_ZF_DL_avg,'all');

    %Compute SE with ZF and phi2
    desSign_ZF_DL_phi2_avg = rho*abs(mean(signalDL_ZF_phi2,2)).^2;
    selfInt_ZF_DL_phi2_avg = rho*mean(abs(signalDL_ZF_phi2).^2,2) - desSign_ZF_DL_phi2_avg;
    IntPR_ZF_DL_phi2_avg = mean(interf_PR_ZF_phi2,2);
    IntNPR_ZF_DL_phi2_avg = mean(interf_NPR_ZF_phi2,2);
    meanSEperUE_ZF_DL_mo_avg = prelogFactor*real(log2(1+ desSign_ZF_DL_phi2_avg./ (selfInt_ZF_DL_phi2_avg + IntPR_ZF_DL_phi2_avg + IntNPR_ZF_DL_phi2_avg + 1)));

    % desSign_ZF_DL_phi2(1,m) = mean(10*log10(desSign_ZF_DL_phi2_avg(1:tp,:)),'all');
    % desSign_ZF_DL_phi2(2,m) = mean(10*log10(desSign_ZF_DL_phi2_avg(tp+1:end,:)),'all');
    % desSign_ZF_DL_phi2(3,m) = mean(10*log10(desSign_ZF_DL_phi2_avg),'all');
    % selfInt_ZF_DL_phi2(1,m) = mean(10*log10(selfInt_ZF_DL_phi2_avg(1:tp,:)),'all');
    % selfInt_ZF_DL_phi2(2,m) = mean(10*log10(selfInt_ZF_DL_phi2_avg(tp+1:end,:)),'all');
    % selfInt_ZF_DL_phi2(3,m) = mean(10*log10(selfInt_ZF_DL_phi2_avg),'all');
    % IntPR_ZF_DL_phi2(1,m) = mean(10*log10(IntPR_ZF_DL_phi2_avg(1:tp,:)),'all');
    % IntPR_ZF_DL_phi2(2,m) = mean(10*log10(IntPR_ZF_DL_phi2_avg(tp+1:end,:)),'all');
    % IntPR_ZF_DL_phi2(3,m) = mean(10*log10(IntPR_ZF_DL_phi2_avg),'all');
    % IntNPR_ZF_DL_phi2(1,m) = mean(10*log10(IntNPR_ZF_DL_phi2_avg(1:tp,:)),'all');
    % IntNPR_ZF_DL_phi2(2,m) = mean(10*log10(IntNPR_ZF_DL_phi2_avg(tp+1:end,:)),'all');
    % IntNPR_ZF_DL_phi2(3,m) = mean(10*log10(IntNPR_ZF_DL_phi2_avg),'all');
    meanSEperUE_ZF_mo_DL(1,m) = mean(meanSEperUE_ZF_DL_mo_avg(1:tp,:),'all');
    meanSEperUE_ZF_mo_DL(2,m) = mean(meanSEperUE_ZF_DL_mo_avg(tp+1:end,:),'all');
    meanSEperUE_ZF_mo_DL(3,m) = mean(meanSEperUE_ZF_DL_mo_avg,'all');

    %Compute SE with ZF and no RIS
    desSign_ZF_DL_nris_avg = rho*abs(mean(signalDL_ZF_nris,2)).^2;
    selfInt_ZF_DL_nris_avg = rho*mean(abs(signalDL_ZF_nris).^2,2) - desSign_ZF_DL_nris_avg;
    IntPR_ZF_DL_nris_avg = mean(interf_PR_ZF_nris,2);
    IntNPR_ZF_DL_nris_avg = mean(interf_NPR_ZF_nris,2);
    meanSEperUE_ZF_DL_nr_avg = prelogFactor*real(log2(1+ desSign_ZF_DL_nris_avg./ (selfInt_ZF_DL_nris_avg + IntPR_ZF_DL_nris_avg + IntNPR_ZF_DL_nris_avg + 1)));

    % desSign_ZF_DL_nris(1,m) = mean(10*log10(desSign_ZF_DL_nris_avg(1:tp,:)),'all');
    % desSign_ZF_DL_nris(2,m) = mean(10*log10(desSign_ZF_DL_nris_avg(tp+1:end,:)),'all');
    % desSign_ZF_DL_nris(3,m) = mean(10*log10(desSign_ZF_DL_nris_avg),'all');
    % selfInt_ZF_DL_nris(1,m) = mean(10*log10(selfInt_ZF_DL_nris_avg(1:tp,:)),'all');
    % selfInt_ZF_DL_nris(2,m) = mean(10*log10(selfInt_ZF_DL_nris_avg(tp+1:end,:)),'all');
    % selfInt_ZF_DL_nris(3,m) = mean(10*log10(selfInt_ZF_DL_nris_avg),'all');
    % IntPR_ZF_DL_nris(1,m) = mean(10*log10(IntPR_ZF_DL_nris_avg(1:tp,:)),'all');
    % IntPR_ZF_DL_nris(2,m) = mean(10*log10(IntPR_ZF_DL_nris_avg(tp+1:end,:)),'all');
    % IntPR_ZF_DL_nris(3,m) = mean(10*log10(IntPR_ZF_DL_nris_avg),'all');
    % IntNPR_ZF_DL_nris(1,m) = mean(10*log10(IntNPR_ZF_DL_nris_avg(1:tp,:)),'all');
    % IntNPR_ZF_DL_nris(2,m) = mean(10*log10(IntNPR_ZF_DL_nris_avg(tp+1:end,:)),'all');
    % IntNPR_ZF_DL_nris(3,m) = mean(10*log10(IntNPR_ZF_DL_nris_avg),'all');
    meanSEperUE_ZF_nr_DL(1,m) = mean(meanSEperUE_ZF_DL_nr_avg(1:tp,:),'all');
    meanSEperUE_ZF_nr_DL(2,m) = mean(meanSEperUE_ZF_DL_nr_avg(tp+1:end,:),'all');
    meanSEperUE_ZF_nr_DL(3,m) = mean(meanSEperUE_ZF_DL_nr_avg,'all'); 

end


% Plot simulation results

% Generating Fig. 4
%Plot spatial configuration
figure
plot(real(BSlocations),imag(BSlocations),'kh')
hold on; box on; grid on;
plot(real(posUE1(:,1)),imag(posUE1(:,1)),'bo')
plot(real(posRIS),imag(posRIS),'r+')
plot(real(posUEs),imag(posUEs),'rv')
legend('BS','UEs w/o RIS','RIS','UEs with RIS')
xlim([-1*cellRadius cellRadius])
ylim([-1*cellRadius cellRadius])
xlabel('distance [m]')
ylabel('distance [m]')


% Generating Fig. 8
figure;

subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr(1,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr(1,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr(1,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR(1,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF(1,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(1,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo(1,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo(1,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('SE UEs w/o RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr(2,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr(2,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr(2,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR(2,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF(2,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(2,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo(2,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo(2,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('SE UEs with RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr(3,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr(3,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr(3,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR(3,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF(3,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(3,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo(3,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo(3,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average SE [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

% Generating a figure similar to Fig. 8 but for DL
figure;

subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr_DL(1,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr_DL(1,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr_DL(1,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_DL(1,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_DL(1,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_DL(1,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo_DL(1,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo_DL(1,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo_DL(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('DL SE UEs w/o RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr_DL(2,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr_DL(2,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr_DL(2,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_DL(2,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_DL(2,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_DL(2,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo_DL(2,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo_DL(2,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo_DL(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('DL SE UEs with RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MR_nr_DL(3,:),'bs-','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_nr_DL(3,:),'ko-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_nr_DL(3,:),'rd-','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_DL(3,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_DL(3,:),'ko-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_DL(3,:),'rd-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MR_mo_DL(3,:),'bs:','LineWidth',1);
plot(Kvalues,meanSEperUE_ZF_mo_DL(3,:),'ko:','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo_DL(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average DL SE [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');



%============ Generating Fig. 9 ==================
figure
subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,signal_MR_nris_avg(1,:),'bs-','LineWidth',1);
plot(Kvalues,signal_ZF_nris_avg(1,:),'ko-','LineWidth',1);
plot(Kvalues,signal_MMSE_nris_avg(1,:),'rd-','LineWidth',1);
plot(Kvalues,signal_MR_phi1_avg(1,:),'bs-.','LineWidth',1);
plot(Kvalues,signal_ZF_phi1_avg(1,:),'ko-.','LineWidth',1);
plot(Kvalues,signal_MMSE_phi1_avg(1,:),'rd-.','LineWidth',1);
plot(Kvalues,signal_MR_phi2_avg(1,:),'bs:','LineWidth',1);
plot(Kvalues,signal_ZF_phi2_avg(1,:),'ko:','LineWidth',1);
plot(Kvalues,signal_MMSE_phi2_avg(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Closest UEs UL Desired Signal [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,signal_MR_nris_avg(2,:),'bs-','LineWidth',1);
plot(Kvalues,signal_ZF_nris_avg(2,:),'ko-','LineWidth',1);
plot(Kvalues,signal_MMSE_nris_avg(2,:),'rd-','LineWidth',1);
plot(Kvalues,signal_MR_phi1_avg(2,:),'bs-.','LineWidth',1);
plot(Kvalues,signal_ZF_phi1_avg(2,:),'ko-.','LineWidth',1);
plot(Kvalues,signal_MMSE_phi1_avg(2,:),'rd-.','LineWidth',1);
plot(Kvalues,signal_MR_phi2_avg(2,:),'bs:','LineWidth',1);
plot(Kvalues,signal_ZF_phi2_avg(2,:),'ko:','LineWidth',1);
plot(Kvalues,signal_MMSE_phi2_avg(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Farthest UEs UL Desired Signal [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,signal_MR_nris_avg(3,:),'bs-','LineWidth',1);
plot(Kvalues,signal_ZF_nris_avg(3,:),'ko-','LineWidth',1);
plot(Kvalues,signal_MMSE_nris_avg(3,:),'rd-','LineWidth',1);
plot(Kvalues,signal_MR_phi1_avg(3,:),'bs-.','LineWidth',1);
plot(Kvalues,signal_ZF_phi1_avg(3,:),'ko-.','LineWidth',1);
plot(Kvalues,signal_MMSE_phi1_avg(3,:),'rd-.','LineWidth',1);
plot(Kvalues,signal_MR_phi2_avg(3,:),'bs:','LineWidth',1);
plot(Kvalues,signal_ZF_phi2_avg(3,:),'ko:','LineWidth',1);
plot(Kvalues,signal_MMSE_phi2_avg(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average UL Desired Signal [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

figure
subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,EstErr_MR_nris_avg(1,:),'bs-','LineWidth',1);
plot(Kvalues,EstErr_ZF_nris_avg(1,:),'ko-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_nris_avg(1,:),'rd-','LineWidth',1);
plot(Kvalues,EstErr_MR_phi1_avg(1,:),'bs-.','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi1_avg(1,:),'ko-.','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi1_avg(1,:),'rd-.','LineWidth',1);
plot(Kvalues,EstErr_MR_phi2_avg(1,:),'bs:','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi2_avg(1,:),'ko:','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi2_avg(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Closest UEs UL Self Interf. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,EstErr_MR_nris_avg(2,:),'bs-','LineWidth',1);
plot(Kvalues,EstErr_ZF_nris_avg(2,:),'ko-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_nris_avg(2,:),'rd-','LineWidth',1);
plot(Kvalues,EstErr_MR_phi1_avg(2,:),'bs-.','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi1_avg(2,:),'ko-.','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi1_avg(2,:),'rd-.','LineWidth',1);
plot(Kvalues,EstErr_MR_phi2_avg(2,:),'bs:','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi2_avg(2,:),'ko:','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi2_avg(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Farthest UEs UL Self Interf. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,EstErr_MR_nris_avg(3,:),'bs-','LineWidth',1);
plot(Kvalues,EstErr_ZF_nris_avg(3,:),'ko-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_nris_avg(3,:),'rd-','LineWidth',1);
plot(Kvalues,EstErr_MR_phi1_avg(3,:),'bs-.','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi1_avg(3,:),'ko-.','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi1_avg(3,:),'rd-.','LineWidth',1);
plot(Kvalues,EstErr_MR_phi2_avg(3,:),'bs:','LineWidth',1);
plot(Kvalues,EstErr_ZF_phi2_avg(3,:),'ko:','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi2_avg(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average UL Self Interf. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

figure
subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,InterfRP_MR_nris_avg(1,:),'bs-','LineWidth',1);
plot(Kvalues,InterfRP_ZF_nris_avg(1,:),'ko-','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_nris_avg(1,:),'rd-','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi1_avg(1,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi1_avg(1,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi1_avg(1,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi2_avg(1,:),'bs:','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi2_avg(1,:),'ko:','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi2_avg(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Closest UEs UL Interf. P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,InterfRP_MR_nris_avg(2,:),'bs-','LineWidth',1);
plot(Kvalues,InterfRP_ZF_nris_avg(2,:),'ko-','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_nris_avg(2,:),'rd-','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi1_avg(2,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi1_avg(2,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi1_avg(2,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi2_avg(2,:),'bs:','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi2_avg(2,:),'ko:','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi2_avg(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Farthest UEs UL Interf. P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,InterfRP_MR_nris_avg(3,:),'bs-','LineWidth',1);
plot(Kvalues,InterfRP_ZF_nris_avg(3,:),'ko-','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_nris_avg(3,:),'rd-','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi1_avg(3,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi1_avg(3,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi1_avg(3,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfRP_MR_phi2_avg(3,:),'bs:','LineWidth',1);
plot(Kvalues,InterfRP_ZF_phi2_avg(3,:),'ko:','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi2_avg(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average UL Interf. P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

figure
subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,InterfNRP_MR_nris_avg(1,:),'bs-','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_nris_avg(1,:),'ko-','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_nris_avg(1,:),'rd-','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi1_avg(1,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi1_avg(1,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi1_avg(1,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi2_avg(1,:),'bs:','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi2_avg(1,:),'ko:','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi2_avg(1,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Closest UEs UL Interf. N.P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,InterfNRP_MR_nris_avg(2,:),'bs-','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_nris_avg(2,:),'ko-','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_nris_avg(2,:),'rd-','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi1_avg(2,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi1_avg(2,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi1_avg(2,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi2_avg(2,:),'bs:','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi2_avg(2,:),'ko:','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi2_avg(2,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Farthest UEs UL Interf. N.P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,InterfNRP_MR_nris_avg(3,:),'bs-','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_nris_avg(3,:),'ko-','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_nris_avg(3,:),'rd-','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi1_avg(3,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi1_avg(3,:),'ko-.','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi1_avg(3,:),'rd-.','LineWidth',1);
plot(Kvalues,InterfNRP_MR_phi2_avg(3,:),'bs:','LineWidth',1);
plot(Kvalues,InterfNRP_ZF_phi2_avg(3,:),'ko:','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi2_avg(3,:),'rd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average UL Interf. N.P.R. [dB]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

% Auxiliar figure
figure
hold on; box on; grid on;
semilogy(Kvalues,meanCorrProd_rps(1,:),'bs-','LineWidth',1);
semilogy(Kvalues,meanCorrProd_rps(2,:),'bs:','LineWidth',1);
semilogy(Kvalues,meanCorrProd_mo(1,:),'rd-','LineWidth',1);
semilogy(Kvalues,meanCorrProd_mo(2,:),'rd:','LineWidth',1);
semilogy(Kvalues,meanCorrProd_nr(1,:),'ko-','LineWidth',1);
semilogy(Kvalues,meanCorrProd_nr(2,:),'ko:','LineWidth',1);
semilogy(Kvalues,meanStVecProd,'m+-.','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Products of Correlation Matrices');

legend('rps Auto','rps Cross','mo Auto','mo Cross','nr Auto','nr Cross','Steer. Vec.','Location','NorthWest');
set(gca,'YScale','log');

% Generating Fig. 9
figure
hold on; box on; grid on;
plot(Kvalues,signal_MMSE_nris_avg(3,:),'ro-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_nris_avg(3,:),'ro-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_nris_avg(3,:),'ro--','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_nris_avg(3,:),'ro:','LineWidth',1);
plot(Kvalues,signal_MMSE_phi1_avg(3,:),'bs-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi1_avg(3,:),'bs-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi1_avg(3,:),'bs--','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi1_avg(3,:),'bs:','LineWidth',1);
plot(Kvalues,signal_MMSE_phi2_avg(3,:),'kd-','LineWidth',1);
plot(Kvalues,EstErr_MMSE_phi2_avg(3,:),'kd-.','LineWidth',1);
plot(Kvalues,InterfRP_MMSE_phi2_avg(3,:),'kd--','LineWidth',1);
plot(Kvalues,InterfNRP_MMSE_phi2_avg(3,:),'kd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('MMSE UL Normalized Signal Powers [dB]');

legend('DS nr','SI nr','IPR nr','INPR nr','DS rps','SI rps','IPR rps','INPR rps','DS mo','SI mo','IPR mo','INPR mo','Location','NorthWest');
%set(gca,'XScale','log');

figure;

subplot(1,3,1)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MMSE_nr(1,:),'ro-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(1,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(1,:),'kd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('SE UEs w/o RIS [bit/s/Hz/user]');

legend('MMSE nr','MMSE rps','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MMSE_nr(2,:),'ro-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(2,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(2,:),'kd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('SE UEs with RIS [bit/s/Hz/user]');

legend('MMSE nr','MMSE rps','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Kvalues,meanSEperUE_MMSE_nr(3,:),'ro-','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE(3,:),'bs-.','LineWidth',1);
plot(Kvalues,meanSEperUE_MMSE_mo(3,:),'kd:','LineWidth',1);

xlabel('Number of Users (K)');
ylabel('Average SE [bit/s/Hz/user]');

legend('MMSE nr','MMSE rps','MMSE mo','Location','NorthWest');
%set(gca,'XScale','log');


%========== Downlink ========================
% figure
% subplot(1,3,1)
% hold on; box on; grid on;
% plot(Kvalues,desSign_MR_DL_nris(1,:),'bs-','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_nris(1,:),'ko-','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_nris(1,:),'rd-','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi1(1,:),'bs-.','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi1(1,:),'ko-.','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi1(1,:),'rd-.','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi2(1,:),'bs:','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi2(1,:),'ko:','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi2(1,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Closest UEs DL Desired Signal [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,2)
% hold on; box on; grid on;
% plot(Kvalues,desSign_MR_DL_nris(2,:),'bs-','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_nris(2,:),'ko-','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_nris(2,:),'rd-','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi1(2,:),'bs-.','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi1(2,:),'ko-.','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi1(2,:),'rd-.','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi2(2,:),'bs:','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi2(2,:),'ko:','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi2(2,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Farthest UEs DL Desired Signal [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,3)
% hold on; box on; grid on;
% plot(Kvalues,desSign_MR_DL_nris(3,:),'bs-','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_nris(3,:),'ko-','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_nris(3,:),'rd-','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi1(3,:),'bs-.','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi1(3,:),'ko-.','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi1(3,:),'rd-.','LineWidth',1);
% plot(Kvalues,desSign_MR_DL_phi2(3,:),'bs:','LineWidth',1);
% plot(Kvalues,desSign_ZF_DL_phi2(3,:),'ko:','LineWidth',1);
% plot(Kvalues,desSign_MMSE_DL_phi2(3,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Average DL Desired Signal [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% 
% figure
% subplot(1,3,1)
% hold on; box on; grid on;
% plot(Kvalues,selfInt_MR_DL_nris(1,:),'bs-','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_nris(1,:),'ko-','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_nris(1,:),'rd-','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi1(1,:),'bs-.','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi1(1,:),'ko-.','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi1(1,:),'rd-.','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi2(1,:),'bs:','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi2(1,:),'ko:','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi2(1,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Closest UEs DL Self Interf. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,2)
% hold on; box on; grid on;
% plot(Kvalues,selfInt_MR_DL_nris(2,:),'bs-','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_nris(2,:),'ko-','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_nris(2,:),'rd-','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi1(2,:),'bs-.','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi1(2,:),'ko-.','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi1(2,:),'rd-.','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi2(2,:),'bs:','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi2(2,:),'ko:','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi2(2,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Farthest UEs DL Self Interf. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,3)
% hold on; box on; grid on;
% plot(Kvalues,selfInt_MR_DL_nris(3,:),'bs-','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_nris(3,:),'ko-','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_nris(3,:),'rd-','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi1(3,:),'bs-.','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi1(3,:),'ko-.','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi1(3,:),'rd-.','LineWidth',1);
% plot(Kvalues,selfInt_MR_DL_phi2(3,:),'bs:','LineWidth',1);
% plot(Kvalues,selfInt_ZF_DL_phi2(3,:),'ko:','LineWidth',1);
% plot(Kvalues,selfInt_MMSE_DL_phi2(3,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Average DL Self Interf. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% figure
% subplot(1,3,1)
% hold on; box on; grid on;
% plot(Kvalues,IntPR_MR_DL_nris(1,:),'bs-','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_nris(1,:),'ko-','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_nris(1,:),'rd-','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi1(1,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi1(1,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi1(1,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi2(1,:),'bs:','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi2(1,:),'ko:','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi2(1,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Closest UEs DL Interf. P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,2)
% hold on; box on; grid on;
% plot(Kvalues,IntPR_MR_DL_nris(2,:),'bs-','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_nris(2,:),'ko-','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_nris(2,:),'rd-','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi1(2,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi1(2,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi1(2,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi2(2,:),'bs:','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi2(2,:),'ko:','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi2(2,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Farthest UEs DL Interf. P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,3)
% hold on; box on; grid on;
% plot(Kvalues,IntPR_MR_DL_nris(3,:),'bs-','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_nris(3,:),'ko-','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_nris(3,:),'rd-','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi1(3,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi1(3,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi1(3,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntPR_MR_DL_phi2(3,:),'bs:','LineWidth',1);
% plot(Kvalues,IntPR_ZF_DL_phi2(3,:),'ko:','LineWidth',1);
% plot(Kvalues,IntPR_MMSE_DL_phi2(3,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Average DL Interf. P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% figure
% subplot(1,3,1)
% hold on; box on; grid on;
% plot(Kvalues,IntNPR_MR_DL_nris(1,:),'bs-','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_nris(1,:),'ko-','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_nris(1,:),'rd-','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi1(1,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi1(1,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi1(1,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi2(1,:),'bs:','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi2(1,:),'ko:','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi2(1,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Closest UEs DL Interf. N.P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,2)
% hold on; box on; grid on;
% plot(Kvalues,IntNPR_MR_DL_nris(2,:),'bs-','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_nris(2,:),'ko-','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_nris(2,:),'rd-','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi1(2,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi1(2,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi1(2,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi2(2,:),'bs:','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi2(2,:),'ko:','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi2(2,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Farthest UEs DL Interf. N.P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');
% 
% subplot(1,3,3)
% hold on; box on; grid on;
% plot(Kvalues,IntNPR_MR_DL_nris(3,:),'bs-','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_nris(3,:),'ko-','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_nris(3,:),'rd-','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi1(3,:),'bs-.','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi1(3,:),'ko-.','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi1(3,:),'rd-.','LineWidth',1);
% plot(Kvalues,IntNPR_MR_DL_phi2(3,:),'bs:','LineWidth',1);
% plot(Kvalues,IntNPR_ZF_DL_phi2(3,:),'ko:','LineWidth',1);
% plot(Kvalues,IntNPR_MMSE_DL_phi2(3,:),'rd:','LineWidth',1);
% 
% xlabel('Number of Users (K)');
% ylabel('Average DL Interf. N.P.R. [dB]');
% 
% legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
% %set(gca,'XScale','log');


