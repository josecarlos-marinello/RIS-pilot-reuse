%This Matlab script can be used to generate the Figure 3 in the article:
%
%José Carlos Marinello Filho, Taufik Abrão, Ekram Hossain, and Amine Mezghani, 
%"Reconfigurable Intelligent Surfaces-Enabled Intra-Cell Pilot Reuse in Massive MIMO Systems"
%
%This is version 1.1 (Last edited: 2023-07-20)
%
%License: This code is licensed under the GPLv2 license. If you in any way
%use this code for research that results in publications, please cite our
%original article listed above.


%Initialization
%close all;
clear;
clc;

% Defining functions
u = @(phi,N,d)exp(-1i*pi*phi*transpose(0:N-1));
ar = @(phi,theta,Mh,Mv,d,lbd)kron(u((2*d/lbd)*sin(phi)*cos(theta),Mh,d),u((2*d/lbd)*sin(theta),Mv,d)); %fix first varying second
rice = @(rfac,los,M,N)sqrt(rfac/(rfac+1))*los+sqrt(1/(2*(rfac+1)))*(randn(M,N)+1i*randn(M,N));

% Select correlation model for the RIS-UEs link
CorrModel = 1; % Sinc-shaped correlation model
%CorrModel = 2; % Exponential correlation model

%Define the variables in each of the simulations

%Select range of number of BS antennas
Mrange = [8 16 32 64 128 256];
%Mrange = 128;

%Correlation factor in exponential correlation model
correlationFactor = 0.5;

%Number of points on the horizontal axis in the final figure
nbrOfPoints = length(Mrange);

%Determine maximum number of BS antennas
Mmax = max(Mrange);

%Select number of channel realizations per setup
nbrOfSpRealizations = 1000;
nbrOfRealizations = 10;

%Cell Radius
cellRadius = 150;

%Define BS positions using complex coordinates
BSlocations = 0;

% Propagation parameters
f = 3e9;
lbd = 3e8/f;
da = lbd/2;

%Pathloss exponent
alpha = 4.2; % no-RIS UEs
alpha2 = 4.2; % RIS-aided UEs

%Constant term in pathloss model (assuming distances in meters)
constantTerm = -35.3;

%Communication bandwidth
bandwidth = 10e6;

%Define total uplink transmit power per UE (mW)
p = 100;

%Define total downlink transmit power per UE (mW)
rho = 100;

%Define noise figure at BS (in dB)
noiseFigure = 10;

%Compute total noise power
noiseVariancedBm = -174 + 10*log10(bandwidth) + noiseFigure;

%Select length of coherence block
tau_c = 200;


% RIS parameters
Ni = 256;
Nv = 16;
Nh = Ni/Nv;
di = lbd/2;
Riceai_dB = [0 3 5 10];
nbrOfRiceFact = length(Riceai_dB);
Riceai = 10.^(Riceai_dB/10);
plexp_ai = 2.3;
elAoD_i = 0;
h_BS = 10;
%elAoD_i = atan(h_BS/(0.2*cellRadius));

%Prepare to save UL simulation results
tr_R2_rps = zeros(2,nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);
tr_R2_mo = zeros(2,nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);
tr_R2_nr = zeros(2,nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_rps = zeros(nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_mo = zeros(nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_nr = zeros(nbrOfRealizations,nbrOfSpRealizations,nbrOfPoints,nbrOfRiceFact,2);

tr_R2_rps_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);
tr_R2_mo_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);
tr_R2_nr_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_rps_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_mo_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);
ProdCorr_nr_avg = zeros(nbrOfPoints,nbrOfRiceFact,2);

% Create the problem structure.
manifold = complexcirclefactory(Ni);
problem.M = manifold;

%Go through all points 
for m = 1:nbrOfPoints

    %Output simulation progress
    disp([num2str(m) ' points out of ' num2str(nbrOfPoints)]);

    %Extract current number of antennas
    M = Mrange(m);

    %Store identity matrix of size M x M
    eyeM = eye(M);

    % Optimized grid of angular positions for the RIS deployment
    N_angs = M*da/lbd;
    step_ang = 1/N_angs;
    AoAa_opt = zeros(4*N_angs,1);
    for ind=-N_angs:N_angs
        AoAa_opt(N_angs+1+ind) = asin(ind*step_ang); %asin(2*ind/M);
    end
    AoAa_opt(2*N_angs+2:end) = AoAa_opt(2:2*N_angs)+pi;
    numElelCircShift = sum(AoAa_opt<0);
    AoAa_opt(AoAa_opt<0) = AoAa_opt(AoAa_opt<0)+2*pi;
    AoAa_opt = circshift(AoAa_opt,-numElelCircShift);
    % figure
    % polarplot(AoAa_opt,ones(size(AoAa_opt)),'r+')
    % figure
    % plot(AoAa_opt,'r+')

    for m2 = 1:nbrOfSpRealizations

        %Deploy UEs at the fixed locations
        Angs = 2*pi*rand(2,1);
        Angs_c = zeros(2,1);
        for indc=1:2
            closestInd = find(abs(Angs(indc)-AoAa_opt) == min(abs(Angs(indc)-AoAa_opt)));
            Angs_c(indc) = AoAa_opt(closestInd);
            if abs(sin(Angs_c(indc)))==1
                indEqAng = abs(sin(Angs_c(1:indc-1)))-1<1e-5;
                if any(indEqAng)
                    closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(closestInd-1)),abs(Angs_c(indc)-AoAa_opt(closestInd+1))),1);
                    Angs_c(indc) = AoAa_opt(closestInd);
                end
            end
            indEqAng = abs(sin(Angs_c(indc))-sin(Angs_c(1:indc-1)))<1e-5;
            if any(indEqAng)
                if closestInd==1
                    nextAng = closestInd+1;
                    prevAng = 4*N_angs;
                elseif closestInd==4*N_angs
                    nextAng = 1;
                    prevAng = closestInd-1;
                else
                    nextAng = closestInd+1;
                    prevAng = closestInd-1;
                end
                closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(prevAng)),abs(Angs_c(indc)-AoAa_opt(nextAng))),1);
                Angs_c(indc) = AoAa_opt(closestInd);
            end
        end
        AoD_ris = pi/6;
        Angs_ue_r = pi/4;
        posRIS = 0.8*cellRadius*exp(1i*Angs);
        posRIS_c = 0.8*cellRadius*exp(1i*Angs_c);
        posUEs_r = 0.2*cellRadius*exp(1i*Angs_ue_r);
        posUEs = zeros(1,2);
        posUEs_c = zeros(1,2);
        for ind=1:2
            posUEs(1,ind) = (posUEs_r*exp(1i*(Angs(ind)-AoD_ris+pi/2)))+posRIS(ind);
            posUEs_c(1,ind) = (posUEs_r*exp(1i*(Angs_c(ind)-AoD_ris+pi/2)))+posRIS_c(ind);
        end

        RIS_boresights = Angs - pi - AoD_ris;
        azAoA_a = angle(BSlocations-posRIS);
        RIS_boresights_c = Angs_c - pi - AoD_ris;
        azAoA_a_c = angle(BSlocations-posRIS_c);
        azAoD_i = AoD_ris;

        %Compute distances between UEs and BS
        distancesBS_RIS = abs(posRIS-BSlocations);
        distancesBS_UEs = abs(posUEs-BSlocations);
        distancesRIS_UEs = abs(posUEs-transpose(posRIS));
        distancesBS_RIS_c = abs(posRIS_c-BSlocations);
        distancesBS_UEs_c = abs(posUEs_c-BSlocations);
        distancesRIS_UEs_c = abs(posUEs_c-transpose(posRIS_c));

        %Compute angles between UEs and BS
        angleBS_UEs = angle(posUEs-BSlocations);
        angleRIS_UEs = angle(posUEs-transpose(posRIS)) - transpose(RIS_boresights);
        angleBS_UEs_c = angle(posUEs_c-BSlocations);
        angleRIS_UEs_c = angle(posUEs_c-transpose(posRIS_c)) - transpose(RIS_boresights_c);

        %Compute distant-dependent path gains (in dB) normalized by the noise power
        channelGaindB_BS_UEs = constantTerm - alpha2*10*log10(distancesBS_UEs) -noiseVariancedBm;
        channelGaindB_BS_RIS = constantTerm - plexp_ai*10*log10(distancesBS_RIS) -noiseVariancedBm;
        channelGaindB_RIS_UEs = constantTerm - plexp_ai*10*log10(distancesRIS_UEs);
        channelGaindB_BS_UEs_c = constantTerm - alpha2*10*log10(distancesBS_UEs_c) -noiseVariancedBm;
        channelGaindB_BS_RIS_c = constantTerm - plexp_ai*10*log10(distancesBS_RIS_c) -noiseVariancedBm;
        channelGaindB_RIS_UEs_c = constantTerm - plexp_ai*10*log10(distancesRIS_UEs_c);

        %Go through all channels and apply path gain
        betas_BS_UEs = 10.^(channelGaindB_BS_UEs/10);
        betas_BS_RIS = 10.^(channelGaindB_BS_RIS/10);
        betas_RIS_UEs = 10.^(channelGaindB_RIS_UEs/10);
        betas_BS_UEs_c = 10.^(channelGaindB_BS_UEs_c/10);
        betas_BS_RIS_c = 10.^(channelGaindB_BS_RIS_c/10);
        betas_RIS_UEs_c = 10.^(channelGaindB_RIS_UEs_c/10);

        if CorrModel == 1
            % RIS correlation matrix under sinc-shaped model
            Rris = zeros(Ni);
            for indr=1:Ni
                for indc=1:Ni
                    col_indr = ceil(indr/Nv);
                    row_indr = mod(indr-1,Nv)+1;
                    col_indc = ceil(indc/Nv);
                    row_indc = mod(indc-1,Nv)+1;
                    dist_elem = sqrt((col_indr - col_indc)^2+(row_indr - row_indc)^2)*di;

                    Rris(indr,indc) = sinc(dist_elem/(lbd/2));
                end
            end
        end
        Rris_UEs = zeros(Ni,Ni,2);
        Rris_UEs_c = zeros(Ni,Ni,2);
        Rues = zeros(M,M,2);
        H_ai_los = zeros(M,Ni,2);
        Phi = zeros(Ni,2);
        Zmat = zeros(Ni,Ni,2);
        Phiopt = zeros(Ni,2);

        Rues_c = zeros(M,M,2);
        H_ai_los_c = zeros(M,Ni,2);
        Phi_c = zeros(Ni,2);
        Zmat_c = zeros(Ni,Ni,2);
        Phiopt_c = zeros(Ni,2);

        for indc = 1:2
            if CorrModel == 1
                Rris_UEs(:,:,indc) = betas_RIS_UEs(indc)*Rris;
                Rris_UEs_c(:,:,indc) = betas_RIS_UEs_c(indc)*Rris;
            elseif CorrModel == 2
                Rris_UEs(:,:,indc) = betas_RIS_UEs(indc)*toeplitz((correlationFactor*exp(1i*angleRIS_UEs(indc))).^(0:Ni-1));
                Rris_UEs_c(:,:,indc) = betas_RIS_UEs_c(indc)*toeplitz((correlationFactor*exp(1i*angleRIS_UEs_c(indc))).^(0:Ni-1));
            end

            H_ai_los(:,:,indc) = u((2*da/lbd)*sin(azAoA_a(indc)),M,da)*ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd)'; % MxNi
            %Phi(:,indc) = ones(Ni,1);
            Phi(:,indc) = ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd);
            if CorrModel == 1
                Zmat(:,:,indc) = conj(Rris).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
            elseif CorrModel == 2
                Zmat(:,:,indc) = conj(Rris_UEs(:,:,indc)).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
            end
            Rues(:,:,indc) = betas_BS_UEs(indc)*toeplitz((correlationFactor*exp(1i*angleBS_UEs(indc))).^(0:M-1));

            H_ai_los_c(:,:,indc) = u((2*da/lbd)*sin(azAoA_a_c(indc)),M,da)*ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd)'; % MxNi
            %Phi(:,indc) = ones(Ni,1);
            Phi_c(:,indc) = ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd);
            if CorrModel == 1
                Zmat_c(:,:,indc) = conj(Rris).*(H_ai_los_c(:,:,indc)'*H_ai_los_c(:,:,indc)); % only LoS component w/o beta ris
            elseif CorrModel == 2
                Zmat(:,:,indc) = conj(Rris_UEs_c(:,:,indc)).*(H_ai_los_c(:,:,indc)'*H_ai_los_c(:,:,indc)); % only LoS component w/o beta ris
            end
            Rues_c(:,:,indc) = betas_BS_UEs_c(indc)*toeplitz((correlationFactor*exp(1i*angleBS_UEs_c(indc))).^(0:M-1));


            % Define the problem cost function and its Euclidean gradient.
            problem.cost  = @(x) -real(x'*Zmat(:,:,indc)*x);
            problem.egrad = @(x) -2*Zmat(:,:,indc)*x;      % notice the 'e' in 'egrad' for Euclidean

            % Numerically check gradient consistency (optional).
            %checkgradient(problem);

            % Solve
            [Phi2, ~, ~, ~] = trustregions(problem);
            Phiopt(:,indc) = Phi2;

            % Define the problem cost function and its Euclidean gradient.
            problem.cost  = @(x) -real(x'*Zmat_c(:,:,indc)*x);
            problem.egrad = @(x) -2*Zmat_c(:,:,indc)*x;      % notice the 'e' in 'egrad' for Euclidean

            % Numerically check gradient consistency (optional).
            %checkgradient(problem);

            % Solve
            %[Phiopt, xcost, info, options] = trustregions(problem, Phi);
            [Phi2, ~, ~, ~] = trustregions(problem);
            Phiopt_c(:,indc) = Phi2;

        end
        clc;
        %Output simulation progress
        disp(['Antennas: ' num2str(m) ' points out of ' num2str(nbrOfPoints)]);
        disp(['Spatial Realizations: ' num2str(m2) ' points out of ' num2str(nbrOfSpRealizations)]);

        for m3=1:nbrOfRiceFact

            Rues_phi1 = zeros(M,M,2);
            Rues_phi2 = zeros(M,M,2);
            Rues_phi1_c = zeros(M,M,2);
            Rues_phi2_c = zeros(M,M,2);
            H_ai = zeros(M,Ni,2);            
            H_ai_c = zeros(M,Ni,2);

            for m4=1:nbrOfRealizations

                for indc=1:2
                    H_ai(:,:,indc) = sqrt(betas_BS_RIS(indc))*rice(Riceai(m3),H_ai_los(:,:,indc),M,Ni);
                    Rues_phi1(:,:,indc) = H_ai(:,:,indc)*diag(Phi(:,indc))*Rris_UEs(:,:,indc)*(H_ai(:,:,indc)*diag(Phi(:,indc)))' + Rues(:,:,indc);
                    Rues_phi2(:,:,indc) = H_ai(:,:,indc)*diag(Phiopt(:,indc))*Rris_UEs(:,:,indc)*(H_ai(:,:,indc)*diag(Phiopt(:,indc)))' + Rues(:,:,indc);
                    H_ai_c(:,:,indc) = sqrt(betas_BS_RIS_c(indc))*rice(Riceai(m3),H_ai_los_c(:,:,indc),M,Ni);
                    Rues_phi1_c(:,:,indc) = H_ai_c(:,:,indc)*diag(Phi_c(:,indc))*Rris_UEs_c(:,:,indc)*(H_ai_c(:,:,indc)*diag(Phi_c(:,indc)))' + Rues_c(:,:,indc);
                    Rues_phi2_c(:,:,indc) = H_ai_c(:,:,indc)*diag(Phiopt_c(:,indc))*Rris_UEs_c(:,:,indc)*(H_ai_c(:,:,indc)*diag(Phiopt_c(:,indc)))' + Rues_c(:,:,indc);

                    tr_R2_rps(indc,m4,m2,m,m3,1) = trace(Rues_phi1(:,:,indc));
                    tr_R2_rps(indc,m4,m2,m,m3,2) = trace(Rues_phi1_c(:,:,indc));
                    tr_R2_mo(indc,m4,m2,m,m3,1) = trace(Rues_phi2(:,:,indc));
                    tr_R2_mo(indc,m4,m2,m,m3,2) = trace(Rues_phi2_c(:,:,indc));
                    tr_R2_nr(indc,m4,m2,m,m3,1) = trace(Rues(:,:,indc));
                    tr_R2_nr(indc,m4,m2,m,m3,2) = trace(Rues_c(:,:,indc));
                end
                
                ProdCorr_rps(m4,m2,m,m3,1) = trace(Rues_phi1(:,:,1)*Rues_phi1(:,:,2))/(tr_R2_rps(1,m4,m2,m,m3,1)*tr_R2_rps(2,m4,m2,m,m3,1));
                ProdCorr_mo(m4,m2,m,m3,1) = trace(Rues_phi2(:,:,1)*Rues_phi2(:,:,2))/(tr_R2_mo(1,m4,m2,m,m3,1)*tr_R2_mo(2,m4,m2,m,m3,1));
                ProdCorr_nr(m4,m2,m,m3,1) = trace(Rues(:,:,1)*Rues(:,:,2))/(tr_R2_nr(1,m4,m2,m,m3,1)*tr_R2_nr(2,m4,m2,m,m3,1));

                ProdCorr_rps(m4,m2,m,m3,2) = trace(Rues_phi1_c(:,:,1)*Rues_phi1_c(:,:,2))/(tr_R2_rps(1,m4,m2,m,m3,2)*tr_R2_rps(2,m4,m2,m,m3,2));
                ProdCorr_mo(m4,m2,m,m3,2) = trace(Rues_phi2_c(:,:,1)*Rues_phi2_c(:,:,2))/(tr_R2_mo(1,m4,m2,m,m3,2)*tr_R2_mo(2,m4,m2,m,m3,2));
                ProdCorr_nr(m4,m2,m,m3,2) = trace(Rues_c(:,:,1)*Rues_c(:,:,2))/(tr_R2_nr(1,m4,m2,m,m3,2)*tr_R2_nr(2,m4,m2,m,m3,2));

            end
        end
    end
    for m3=1:nbrOfRiceFact
        tr_R2_rps_avg(m,m3,1) = mean(tr_R2_rps(:,:,:,m,m3,1),'all');
        tr_R2_mo_avg(m,m3,1) = mean(tr_R2_mo(:,:,:,m,m3,1),'all');
        tr_R2_nr_avg(m,m3,1) = mean(tr_R2_nr(:,:,:,m,m3,1),'all');
        ProdCorr_rps_avg(m,m3,1) = mean(ProdCorr_rps(:,:,m,m3,1),'all');
        ProdCorr_mo_avg(m,m3,1) = mean(ProdCorr_mo(:,:,m,m3,1),'all');
        ProdCorr_nr_avg(m,m3,1) = mean(ProdCorr_nr(:,:,m,m3,1),'all');

        tr_R2_rps_avg(m,m3,2) = mean(tr_R2_rps(:,:,:,m,m3,2),'all');
        tr_R2_mo_avg(m,m3,2) = mean(tr_R2_mo(:,:,:,m,m3,2),'all');
        tr_R2_nr_avg(m,m3,2) = mean(tr_R2_nr(:,:,:,m,m3,2),'all');
        ProdCorr_rps_avg(m,m3,2) = mean(ProdCorr_rps(:,:,m,m3,2),'all');
        ProdCorr_mo_avg(m,m3,2) = mean(ProdCorr_mo(:,:,m,m3,2),'all');
        ProdCorr_nr_avg(m,m3,2) = mean(ProdCorr_nr(:,:,m,m3,2),'all');
    end
end

tr_R2_rps_avg_b = tr_R2_rps_avg;
tr_R2_mo_avg_b = tr_R2_mo_avg;
tr_R2_nr_avg_b = tr_R2_nr_avg;
ProdCorr_rps_avg_b = ProdCorr_rps_avg;
ProdCorr_mo_avg_b = ProdCorr_mo_avg;
ProdCorr_nr_avg_b = ProdCorr_nr_avg;

tr_R2_rps_avg(end-1:end,:,:) = tr_R2_rps_avg_b;
tr_R2_mo_avg(end-1:end,:,:) = tr_R2_mo_avg_b;
tr_R2_nr_avg(end-1:end,:,:) = tr_R2_nr_avg_b;
ProdCorr_rps_avg(end-1:end,:,:) = ProdCorr_rps_avg_b;
ProdCorr_mo_avg(end-1:end,:,:) = ProdCorr_mo_avg_b;
ProdCorr_nr_avg(end-1:end,:,:) = ProdCorr_nr_avg_b;

% Plot simulation results

% Generating Fig. 4
%Plot spatial configuration
figure
plot(real(BSlocations),imag(BSlocations),'kh')
hold on; box on; grid on;
plot(real(posUEs),imag(posUEs),'bo')
plot(real(posRIS),imag(posRIS),'b+')
plot(real(posUEs_c),imag(posUEs_c),'ro')
plot(real(posRIS_c),imag(posRIS_c),'r+')
legend('BS','UEs orig','RIS orig','UEs corr','RIS corr')
xlim([-1*cellRadius cellRadius])
ylim([-1*cellRadius cellRadius])
xlabel('distance [m]')
ylabel('distance [m]')


% Generating Fig. 3
figure;

subplot(2,2,1)
hold on; box on; grid on;
plot(Mrange,tr_R2_nr_avg(:,1,1),'bs--','LineWidth',1);
plot(Mrange,tr_R2_nr_avg(:,1,2),'bs:','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,1,1),'rd--','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,1,2),'rd:','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,1,1),'ko--','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,1,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Auto Trace r_f = ',num2str(Riceai_dB(1)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');

subplot(2,2,2)
hold on; box on; grid on;
plot(Mrange,tr_R2_nr_avg(:,2,1),'bs--','LineWidth',1);
plot(Mrange,tr_R2_nr_avg(:,2,2),'bs:','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,2,1),'rd--','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,2,2),'rd:','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,2,1),'ko--','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,2,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Auto Trace r_f = ',num2str(Riceai_dB(2)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');

subplot(2,2,3)
hold on; box on; grid on;
plot(Mrange,tr_R2_nr_avg(:,3,1),'bs--','LineWidth',1);
plot(Mrange,tr_R2_nr_avg(:,3,2),'bs:','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,3,1),'rd--','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,3,2),'rd:','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,3,1),'ko--','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,3,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Auto Trace r_f = ',num2str(Riceai_dB(3)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');

subplot(2,2,4)
hold on; box on; grid on;
plot(Mrange,tr_R2_nr_avg(:,4,1),'bs--','LineWidth',1);
plot(Mrange,tr_R2_nr_avg(:,4,2),'bs:','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,4,1),'rd--','LineWidth',1);
plot(Mrange,tr_R2_rps_avg(:,4,2),'rd:','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,4,1),'ko--','LineWidth',1);
plot(Mrange,tr_R2_mo_avg(:,4,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Auto Trace r_f = ',num2str(Riceai_dB(4)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');

% Generating Fig. 3
figure;

subplot(2,2,1)
hold on; box on; grid on;
plot(Mrange,ProdCorr_nr_avg(:,1,1),'bs--','LineWidth',1);
plot(Mrange,ProdCorr_nr_avg(:,1,2),'bs:','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,1,1),'rd--','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,1,2),'rd:','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,1,1),'ko--','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,1,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Cross Trace r_f = ',num2str(Riceai_dB(1)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');
set(gca,'YScale','log');

subplot(2,2,2)
hold on; box on; grid on;
plot(Mrange,ProdCorr_nr_avg(:,2,1),'bs--','LineWidth',1);
plot(Mrange,ProdCorr_nr_avg(:,2,2),'bs:','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,2,1),'rd--','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,2,2),'rd:','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,2,1),'ko--','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,2,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Cross Trace r_f = ',num2str(Riceai_dB(2)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');
set(gca,'YScale','log');

subplot(2,2,3)
hold on; box on; grid on;
plot(Mrange,ProdCorr_nr_avg(:,3,1),'bs--','LineWidth',1);
plot(Mrange,ProdCorr_nr_avg(:,3,2),'bs:','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,3,1),'rd--','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,3,2),'rd:','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,3,1),'ko--','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,3,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Cross Trace r_f = ',num2str(Riceai_dB(3)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');
set(gca,'YScale','log');

subplot(2,2,4)
hold on; box on; grid on;
plot(Mrange,ProdCorr_nr_avg(:,4,1),'bs--','LineWidth',1);
plot(Mrange,ProdCorr_nr_avg(:,4,2),'bs:','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,4,1),'rd--','LineWidth',1);
plot(Mrange,ProdCorr_rps_avg(:,4,2),'rd:','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,4,1),'ko--','LineWidth',1);
plot(Mrange,ProdCorr_mo_avg(:,4,2),'ko:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel(['Cross Trace r_f = ',num2str(Riceai_dB(4)),' dB']);

legend('nr or.','nr opt.','rps or.','rps opt.','mo or.','mo opt.','Location','NorthWest');
set(gca,'XScale','log');
set(gca,'YScale','log');


