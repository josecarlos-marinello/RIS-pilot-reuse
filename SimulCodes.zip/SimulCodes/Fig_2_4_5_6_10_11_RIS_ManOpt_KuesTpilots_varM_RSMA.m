%This Matlab script can be used to generate the Figures 2, 4, 5, 6, 10 and 11 in the article:
%
%José Carlos Marinello Filho, Taufik Abrão, Ekram Hossain, and Amine Mezghani, 
%"Reconfigurable Intelligent Surfaces-Enabled Intra-Cell Pilot Reuse in Massive MIMO Systems"
%
%This is version 1.1 (Last edited: 2023-07-20)
%
%License: This code is licensed under the GPLv2 license. If you in any way
%use this code for research that results in publications, please cite our
%original article listed above.


%Initialization
%close all;
clear;
clc;

% Defining functions
u = @(phi,N,d)exp(-1i*pi*phi*transpose(0:N-1));
ar = @(phi,theta,Mh,Mv,d,lbd)kron(u((2*d/lbd)*sin(phi)*cos(theta),Mh,d),u((2*d/lbd)*sin(theta),Mv,d)); %fix first varying second
rice = @(rfac,los,M,N)sqrt(rfac/(rfac+1))*los+sqrt(1/(2*(rfac+1)))*(randn(M,N)+1i*randn(M,N));

% Select correlation model for the RIS-UEs link
CorrModel = 1; % Sinc-shaped correlation model
%CorrModel = 2; % Exponential correlation model

%Define the variables in each of the simulations

%Number of UEs per BS
K = 4;

%Number of clusters and PRF
%nc = 4;
nc = K;

%Length of pilot sequences
%tp = K/nc;
tp = 1;

%Select range of number of BS antennas
%Mrange = [8 16 32 64 128 256];
Mrange = 128;

%Correlation factor in exponential correlation model
correlationFactor = 0.5;

%Number of points on the horizontal axis in the final figure
nbrOfPoints = length(Mrange);

%Select number of channel realizations per setup
nbrOfRealizations = 1000;

%Cell Radius
cellRadius = 150;

%Define BS positions using complex coordinates
BSlocations = 0;


% Propagation parameters
f = 3e9;
lbd = 3e8/f;
da = lbd/2;

% Optimized grid of angular positions for the RIS deployment
N_angs = Mrange(1)*da/lbd;
step_ang = 1/N_angs;
AoAa_opt = zeros(4*N_angs,1);
for ind=-N_angs:N_angs
    AoAa_opt(N_angs+1+ind) = asin(ind*step_ang); %asin(2*ind/M);
end
AoAa_opt(2*N_angs+2:end) = AoAa_opt(2:2*N_angs)+pi;
numElelCircShift = sum(AoAa_opt<0);
AoAa_opt(AoAa_opt<0) = AoAa_opt(AoAa_opt<0)+2*pi;
AoAa_opt = circshift(AoAa_opt,-numElelCircShift);

% % Generating Fig. 2
% figure
% polarplot(AoAa_opt,ones(size(AoAa_opt)),'r+')
% figure
% plot(AoAa_opt,'r+')


%Deploy UEs at the fixed locations
D_ang_c = 2*pi/(nc);
Angs_c = transpose(D_ang_c*((1:nc)-0.5));
for indc=2:nc
    closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt)));
    Angs_c(indc) = AoAa_opt(closestInd);
    if abs(sin(Angs_c(indc)))==1
        indEqAng = abs(sin(Angs_c(2:indc-1)))-1<1e-5;
        if any(indEqAng)
            closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(closestInd-1)),abs(Angs_c(indc)-AoAa_opt(closestInd+1))),1);
            Angs_c(indc) = AoAa_opt(closestInd);
        end
    end
    indEqAng = abs(sin(Angs_c(indc))-sin(Angs_c(2:indc-1)))<1e-5;
    if any(indEqAng)
        closestInd = find(abs(Angs_c(indc)-AoAa_opt) == min(abs(Angs_c(indc)-AoAa_opt(closestInd-1)),abs(Angs_c(indc)-AoAa_opt(closestInd+1))),1);
        Angs_c(indc) = AoAa_opt(closestInd);
    end
end
AoD_ris = pi/6;
Dang_ris = pi/2;
D_ang_ues = Dang_ris/(tp+1);
Angs_ue_c = transpose(D_ang_ues*(1:tp));
posRIS = 0.8*cellRadius*exp(1i*Angs_c(2:nc));
posUEs_c = 0.2*cellRadius*exp(1i*Angs_ue_c);
posUEs = zeros(tp,nc);
for ind=2:nc
    posUEs(:,ind) = (posUEs_c*exp(1i*(Angs_c(ind)-AoD_ris+pi/2)))+posRIS(ind-1);
end
posUEs(:,1) = 0.6*cellRadius*exp(1i*Angs_c(1))+0.1*cellRadius*exp(1i*(transpose(1:tp))*(2*pi/tp));
posUE1 = posUEs(:,1);
posUEs = posUEs(:,2:end);
RIS_boresights = Angs_c - pi - AoD_ris;

%Pathloss exponent
alpha = 4.2; % no-RIS UEs
alpha2 = 4.2; % RIS-aided UEs

%Constant term in pathloss model (assuming distances in meters)
constantTerm = -35.3;

%Communication bandwidth
bandwidth = 10e6;

%Define total uplink transmit power per UE (mW)
p = 100;

%Define total downlink transmit power per UE (mW)
rho = 100;

%Define noise figure at BS (in dB)
noiseFigure = 10;

%Compute total noise power
noiseVariancedBm = -174 + 10*log10(bandwidth) + noiseFigure;

%Select length of coherence block
tau_c = 200;

% Define RSMA parameters
deltaP = 0.05;
Pvec = 0:deltaP:1;
Pt = K*rho;
Pc = Pt*(1-Pvec);
Pp = (Pt/K)*Pvec;
numPow = length(Pvec);


%Prepare to save UL simulation results
meanSEperUE_MR = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE = zeros(K,nbrOfPoints);
meanSEperUE_MZF = zeros(K,nbrOfPoints);

meanSEperUE_MR_mo = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE_mo = zeros(K,nbrOfPoints);
meanSEperUE_MZF_mo = zeros(K,nbrOfPoints);

meanSEperUE_MR_nr = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE_nr = zeros(K,nbrOfPoints);
meanSEperUE_MZF_nr = zeros(K,nbrOfPoints);

%Prepare to save DL simulation results
SE_rsma_mr_p = zeros(K,nbrOfPoints);
SE_rsma_mr_ue = zeros(K,nbrOfPoints);
SE_rsma_mr_c = zeros(1,nbrOfPoints);
sumSE_mr_rsma = zeros(1,nbrOfPoints);
indPopt_mr_rsma = zeros(1,nbrOfPoints);

SE_rsma_mmse_p = zeros(K,nbrOfPoints);
SE_rsma_mmse_ue = zeros(K,nbrOfPoints);
SE_rsma_mmse_c = zeros(1,nbrOfPoints);
sumSE_mmse_rsma = zeros(1,nbrOfPoints);
indPopt_mmse_rsma = zeros(1,nbrOfPoints);

meanSEperUE_MR_DL = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE_DL = zeros(K,nbrOfPoints);
meanSEperUE_MZF_DL = zeros(K,nbrOfPoints);

meanSEperUE_MR_mo_DL = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE_mo_DL = zeros(K,nbrOfPoints);
meanSEperUE_MZF_mo_DL = zeros(K,nbrOfPoints);

meanSEperUE_MR_nr_DL = zeros(K,nbrOfPoints);
meanSEperUE_MMMSE_nr_DL = zeros(K,nbrOfPoints);
meanSEperUE_MZF_nr_DL = zeros(K,nbrOfPoints);

tr_R2 = zeros(nc-1,nbrOfPoints);

% RIS parameters
Ni = 256;
Nv = 16;
Nh = Ni/Nv;
di = lbd/2;
Riceai_dB = 5;
Riceai = 10.^(Riceai_dB/10);
plexp_ai = 2.3;
elAoD_i = 0;
h_BS = 10;
%elAoD_i = atan(h_BS/(0.2*cellRadius));
azAoA_a = angle(BSlocations-posRIS);
azAoD_i = AoD_ris;

%Compute distances between UEs, BS and RIS
distancesBS_RIS = abs(posRIS-BSlocations);
distancesBS_UE1 = abs(posUE1-BSlocations);
distancesBS_UEs = abs(posUEs-BSlocations);
distancesRIS_UEs = abs(posUEs-repmat(transpose(posRIS),tp,1));

%Compute angles between UEs, BS and RIS
angleBS_UE1 = angle(posUE1-BSlocations);
angleBS_UEs = angle(posUEs-BSlocations);
angleRIS_UEs = angle(posUEs-repmat(transpose(posRIS),tp,1)) - repmat(transpose(RIS_boresights(2:end)),tp,1);

%Compute distant-dependent path gains (in dB) normalized by the noise power
channelGaindB_BS_UE1 = constantTerm - alpha*10*log10(distancesBS_UE1) -noiseVariancedBm;
channelGaindB_BS_UEs = constantTerm - alpha2*10*log10(distancesBS_UEs) -noiseVariancedBm;
channelGaindB_BS_RIS = constantTerm - plexp_ai*10*log10(distancesBS_RIS) -noiseVariancedBm;
channelGaindB_RIS_UEs = constantTerm - plexp_ai*10*log10(distancesRIS_UEs);

%Go through all channels and apply path gain
betas_BS_UE1 = 10.^(channelGaindB_BS_UE1/10);
betas_BS_UEs = 10.^(channelGaindB_BS_UEs/10);
betas_BS_RIS = 10.^(channelGaindB_BS_RIS/10);
betas_RIS_UEs = 10.^(channelGaindB_RIS_UEs/10);

if CorrModel == 1
    % RIS correlation matrix under sinc-shaped model
    Rris = zeros(Ni);
    for indr=1:Ni
        for indc=1:Ni
            col_indr = ceil(indr/Nv);
            row_indr = mod(indr-1,Nv)+1;
            col_indc = ceil(indc/Nv);
            row_indc = mod(indc-1,Nv)+1;
            dist_elem = sqrt((col_indr - col_indc)^2+(row_indr - row_indc)^2)*di;

            Rris(indr,indc) = sinc(dist_elem/(lbd/2));
        end
    end
end
Rris_UEs = zeros(Ni,Ni,tp,nc-1);
for indc = 1:nc-1
    for indk = 1:tp
        if CorrModel == 1
            Rris_UEs(:,:,indk,indc) = betas_RIS_UEs(indk,indc)*Rris;
        elseif CorrModel == 2
            Rris_UEs(:,:,indk,indc) = betas_RIS_UEs(indk,indc)*toeplitz((correlationFactor*exp(1i*angleRIS_UEs(indk,indc))).^(0:Ni-1));
        end
    end
end
if CorrModel == 2
    Rris_sum = reshape(sum(Rris_UEs,3),[Ni Ni nc-1]);
end

% Create the problem structure.
manifold = complexcirclefactory(Ni);
problem.M = manifold;

%Go through all points
for m = 1:nbrOfPoints

    %Output simulation progress
    disp([num2str(m) ' points out of ' num2str(nbrOfPoints)]);

    %Extract current number of antennas
    M = Mrange(m);

    %Generate covariance matrix using the exponential
    %correlation model
    Rue1 = zeros(M,M,tp);
    for indk = 1:tp
        Rue1(:,:,indk) = betas_BS_UE1(indk,1)*toeplitz((correlationFactor*exp(1i*angleBS_UE1(indk,1))).^(0:M-1));
    end
    Rues = zeros(M,M,tp,nc-1);
    H_ai_los = zeros(M,Ni,nc-1);
    H_ai = zeros(M,Ni,nc-1);
    Phi = zeros(Ni,nc-1);
    Rues_phi1 = zeros(M,M,tp,nc-1);
    Zmat = zeros(Ni,Ni,nc-1);
    for indc = 1:nc-1
        H_ai_los(:,:,indc) = u((2*da/lbd)*sin(azAoA_a(indc)),M,da)*ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd)'; % MxNi
        H_ai(:,:,indc) = sqrt(betas_BS_RIS(indc))*rice(Riceai,H_ai_los(:,:,indc),M,Ni);
        %Phi(:,indc) = ones(Ni,1);
        Phi(:,indc) = ar(azAoD_i,elAoD_i,Nh,Nv,di,lbd);
        if CorrModel == 1
            Zmat(:,:,indc) = conj(Rris).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
        elseif CorrModel == 2
            Zmat(:,:,indc) = conj(Rris_sum(:,:,indc)).*(H_ai_los(:,:,indc)'*H_ai_los(:,:,indc)); % only LoS component w/o beta ris
        end
        for indk=1:tp
            Rues(:,:,indk,indc) = betas_BS_UEs(indk,indc)*toeplitz((correlationFactor*exp(1i*angleBS_UEs(indk,indc))).^(0:M-1));
            Rues_phi1(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phi(:,indc))*Rris_UEs(:,:,indk,indc)*(H_ai(:,:,indc)*diag(Phi(:,indc)))' + Rues(:,:,indk,indc);
        end
    end

    %Generate uncorrelated Rayleigh fading channel realizations
    Hue1 = (randn(M,nbrOfRealizations,tp)+1i*randn(M,nbrOfRealizations,tp));
    Hues = (randn(M,nbrOfRealizations,tp,nc-1)+1i*randn(M,nbrOfRealizations,tp,nc-1));
    Hues_ris = (randn(Ni,nbrOfRealizations,tp,nc-1)+1i*randn(Ni,nbrOfRealizations,tp,nc-1));

    %Store identity matrix of size M x M
    eyeM = eye(M);

    %Apply covariance structure to the uncorrelated realizations
    Rsqrt_UE1 = zeros(size(Rue1));
    for indk=1:tp
        Rsqrt_UE1(:,:,indk) = sqrtm(Rue1(:,:,indk));
        Hue1(:,:,indk) = sqrt(0.5)*Rsqrt_UE1(:,:,indk)*Hue1(:,:,indk);
    end

    Rsqrt_UEs = zeros(M,M,tp,nc-1);
    Rrissqrt_UEs = zeros(Ni,Ni,tp,nc-1);
    Hues_phi1 = zeros(M,nbrOfRealizations,tp,nc-1);
    Hues_phi2 = zeros(M,nbrOfRealizations,tp,nc-1);
    Phiopt = zeros(Ni,nc-1);
    Rues_phi2 = zeros(M,M,tp,nc-1);
    for indc = 1:nc-1
              
        % Define the problem cost function and its Euclidean gradient.
        problem.cost  = @(x) -real(x'*Zmat(:,:,indc)*x);
        problem.egrad = @(x) -2*Zmat(:,:,indc)*x;      % notice the 'e' in 'egrad' for Euclidean

        % Numerically check gradient consistency (optional).
        %checkgradient(problem);

        % Solve
        [Phi2, xcost, info, options] = trustregions(problem);
        Phiopt(:,indc) = Phi2;

        tr_R2(indc,m) = -xcost;

        for indk=1:tp
            Rsqrt_UEs(:,:,indk,indc) = sqrtm(Rues(:,:,indk,indc));
            Hues(:,:,indk,indc) = sqrt(0.5)*Rsqrt_UEs(:,:,indk,indc)*Hues(:,:,indk,indc);
            Rrissqrt_UEs(:,:,indk,indc) = sqrtm(Rris_UEs(:,:,indk,indc));
            Hues_ris(:,:,indk,indc) = sqrt(0.5)*Rrissqrt_UEs(:,:,indk,indc)*Hues_ris(:,:,indk,indc);
            Hues_phi1(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phi(:,indc))*Hues_ris(:,:,indk,indc) + Hues(:,:,indk,indc);

            Rues_phi2(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phiopt(:,indc))*Rris_UEs(:,:,indk,indc)*(H_ai(:,:,indc)*diag(Phiopt(:,indc)))' + Rues(:,:,indk,indc);
            %Rue2_phi2 = H_ai_los*diag(Phiopt)*Rris*(H_ai_los*diag(Phiopt))' + Rue2;
            Hues_phi2(:,:,indk,indc) = H_ai(:,:,indc)*diag(Phiopt(:,indc))*Hues_ris(:,:,indk,indc) + Hues(:,:,indk,indc);
        end
    end

    % Dimensions: M x MCt x tp x prf
    H_phi1 = cat(4,Hue1,Hues_phi1);    
    H_phi2 = cat(4,Hue1,Hues_phi2);
    H_nris = cat(4,Hue1,Hues);

    % MMSE estimation

    %Generate realizations of normalized noise
    Np = sqrt(0.5)*(randn(M,nbrOfRealizations,tp) + 1i*randn(M,nbrOfRealizations,tp));

    
    %Compute processed pilot signal for all UEs
    % Dimensions: M x MCt x tp
    Yp_phi1 = sqrt(p)*tp*sum(H_phi1,4) + sqrt(tp)*Np;
    Yp_phi2 = sqrt(p)*tp*sum(H_phi2,4) + sqrt(tp)*Np;
    Yp_nris = sqrt(p)*tp*sum(H_nris,4) + sqrt(tp)*Np;

    %Compute the matrix that is inverted in the MMSE channel estimation
    denomMatrix_phi1 = (p*tp*(Rue1+sum(Rues_phi1,4)) + eyeM);
    denomMatrix_phi2 = (p*tp*(Rue1+sum(Rues_phi2,4)) + eyeM);
    denomMatrix_nris = (p*tp*(Rue1+sum(Rues,4)) + eyeM);

    %Prepare to store estimation error covariance matrices
    C_MMSE_phi1 = zeros(M,M,tp,nc);
    C_MMSE_phi2 = zeros(M,M,tp,nc);
    C_MMSE_nris = zeros(M,M,tp,nc);

    %Prepare to store MMSE channel estimates
    Hhat_MMSE_phi1 = zeros(M,nbrOfRealizations,tp,nc);
    Hhat_MMSE_phi2 = zeros(M,nbrOfRealizations,tp,nc);
    Hhat_MMSE_nris = zeros(M,nbrOfRealizations,tp,nc);

    for indk=1:tp
        %Estimate channel between BS and UEs
        invQ_phi1 = eyeM / denomMatrix_phi1(:,:,indk);
        invQ_phi2 = eyeM / denomMatrix_phi2(:,:,indk);
        invQ_nris = eyeM / denomMatrix_nris(:,:,indk);
        numdenomMatrix_ue1_phi1 = Rue1(:,:,indk)*invQ_phi1;
        numdenomMatrix_ue1_phi2 = Rue1(:,:,indk)*invQ_phi2;
        numdenomMatrix_ue1_nris = Rue1(:,:,indk)*invQ_nris;
        Hhat_MMSE_phi1(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_phi1*Yp_phi1(:,:,indk);
        Hhat_MMSE_phi2(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_phi2*Yp_phi2(:,:,indk);
        Hhat_MMSE_nris(:,:,indk,1) = sqrt(p)*numdenomMatrix_ue1_nris*Yp_nris(:,:,indk);

        %Compute corresponding error covariance matrix
        C_MMSE_phi1(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_phi1*Rue1(:,:,indk);
        C_MMSE_phi2(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_phi2*Rue1(:,:,indk);
        C_MMSE_nris(:,:,indk,1) = Rue1(:,:,indk) - p*tp*numdenomMatrix_ue1_nris*Rue1(:,:,indk);

        for indc=2:nc
            %Estimate channel between BS and UEs
            numdenomMatrix_ue2_phi1 = Rues_phi1(:,:,indk,indc-1)*invQ_phi1;
            Hhat_MMSE_phi1(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_phi1*Yp_phi1(:,:,indk);
            numdenomMatrix_ue2_phi2 = Rues_phi2(:,:,indk,indc-1)*invQ_phi2;
            Hhat_MMSE_phi2(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_phi2*Yp_phi2(:,:,indk);
            numdenomMatrix_ue2_nris = Rues(:,:,indk,indc-1)*invQ_nris;
            Hhat_MMSE_nris(:,:,indk,indc) = sqrt(p)*numdenomMatrix_ue2_nris*Yp_nris(:,:,indk);

            %Compute corresponding error covariance matrix
            C_MMSE_phi1(:,:,indk,indc) = Rues_phi1(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_phi1*Rues_phi1(:,:,indk,indc-1);
            C_MMSE_phi2(:,:,indk,indc) = Rues_phi2(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_phi2*Rues_phi2(:,:,indk,indc-1);
            C_MMSE_nris(:,:,indk,indc) = Rues(:,:,indk,indc-1) - p*tp*numdenomMatrix_ue2_nris*Rues(:,:,indk,indc-1);
        end
    end


    %Store identity matrices of different sizes
    eyeK = eye(K);

    %Compute the pre-log factor assuming only uplink transmission
    prelogFactor = (tau_c-tp)/(tau_c);

    %Compute sum of estimation error covariance matrices for all cells
    C_totM_phi1 = p*sum(sum(C_MMSE_phi1,4),3);
    C_totM_phi2 = p*sum(sum(C_MMSE_phi2,4),3);
    C_totM_nris = p*sum(sum(C_MMSE_nris,4),3);

    %Prepare to store simulation results
    SE_MR_phi1 = zeros(K,nbrOfRealizations);
    SE_MMMSE_phi1 = zeros(K,nbrOfRealizations);
    SE_MZF_phi1 = zeros(K,nbrOfRealizations);

    SE_MR_phi2 = zeros(K,nbrOfRealizations);
    SE_MMMSE_phi2 = zeros(K,nbrOfRealizations);
    SE_MZF_phi2 = zeros(K,nbrOfRealizations);

    SE_MR_nris = zeros(K,nbrOfRealizations);
    SE_MMMSE_nris = zeros(K,nbrOfRealizations);
    SE_MZF_nris = zeros(K,nbrOfRealizations);

    %Prepare to store simulation results for signal gains
    signal_MR_phi1 = zeros(K,1);
    signal_MR_phi2 = zeros(K,1);
    signal_MR_nris = zeros(K,1);
    signal_MMMSE_phi1 = zeros(K,1);
    signal_MMMSE_phi2 = zeros(K,1);
    signal_MMMSE_nris = zeros(K,1);
    signal_MZF_phi1 = zeros(K,1);
    signal_MZF_phi2 = zeros(K,1);
    signal_MZF_nris = zeros(K,1);


    %Prepare to store simulation results for sum interference powers
    interf_MR_phi1 = zeros(K,1);
    interf_MR_phi2 = zeros(K,1);
    interf_MR_nris = zeros(K,1);
    interf_MMMSE_phi1 = zeros(K,1);
    interf_MMMSE_phi2 = zeros(K,1);
    interf_MMMSE_nris = zeros(K,1);
    interf_MZF_phi1 = zeros(K,1);
    interf_MZF_phi2 = zeros(K,1);
    interf_MZF_nris = zeros(K,1);
    interf_MMMSE_rsma = zeros(K,numPow);

    RueAll = cat(3,Rue1,reshape(Rues,[M M nc-1]));
    Umat = zeros(K);
    for indk1=1:K
        for indk2=1:K
            Umat(indk1,indk2) = real((1/(p*tp))*trace(RueAll(:,:,indk1)*denomMatrix_nris*RueAll(:,:,indk2)));
        end
    end

    %RSMA: optimizing weights of the common precoder
    cvx_begin
        variables t A(K);
        maximize( t )
        subject to
            t <= transpose(A)*Umat;
            norm(A)<=1;
    cvx_end

    signal_MRr = zeros(K,K,numPow,nbrOfRealizations);
    signal_MMSEr = zeros(K,K,numPow,nbrOfRealizations);
    SignalGainWc = zeros(K,nbrOfRealizations);

    % Go through all channel realizations
    for n = 1:nbrOfRealizations

        %Extract actual channel realizations from all users to BS j
        H_all_phi1 = reshape(H_phi1(:,n,:,:),[M K]);
        H_all_phi2 = reshape(H_phi2(:,n,:,:),[M K]);
        H_all_nris = reshape(H_nris(:,n,:,:),[M K]);

        %Extract channel estimate realizations from all users to BS j
        Hhat_all_phi1 = reshape(Hhat_MMSE_phi1(:,n,:,:),[M K]);
        Hhat_all_phi2 = reshape(Hhat_MMSE_phi2(:,n,:,:),[M K]);
        Hhat_all_nris = reshape(Hhat_MMSE_nris(:,n,:,:),[M K]);

        %Compute MR matrix
        V_MR_phi1 = Hhat_all_phi1;
        V_MR_phi2 = Hhat_all_phi2;
        V_MR_nris = Hhat_all_nris;

        %Compute M-MMSE matrix
        V_MMMSE_phi1 = p*(p*(Hhat_all_phi1*Hhat_all_phi1')+C_totM_phi1+eyeM)\V_MR_phi1;
        V_MMMSE_phi2 = p*(p*(Hhat_all_phi2*Hhat_all_phi2')+C_totM_phi2+eyeM)\V_MR_phi2;
        V_MMMSE_nris = p*(p*(Hhat_all_nris*Hhat_all_nris')+C_totM_nris+eyeM)\V_MR_nris;

        %Compute M-ZF matrix
        V_MZF_phi1 = (Hhat_all_phi1/((Hhat_all_phi1'*Hhat_all_phi1+1e-14*eyeK)))*eyeK;
        V_MZF_phi2 = (Hhat_all_phi2/((Hhat_all_phi2'*Hhat_all_phi2+1e-14*eyeK)))*eyeK;
        V_MZF_nris = (Hhat_all_nris/((Hhat_all_nris'*Hhat_all_nris+1e-14*eyeK)))*eyeK;

        % RSMA: computing weighted MR common precoder
        wc = Hhat_all_nris*A;
        wc = wc/norm(wc);
        SignalGainWc(:,n) = transpose(wc'*H_all_nris);
        

        % RSMA: computing MMSE precoder with different powers
        for indP=2:numPow

            %M-MMSE precoding no RIS
            C_totM_rsma = (Pp(indP)/p)*C_totM_nris;
            V_MMSE_rsma = Pp(indP)*(Pp(indP)*(Hhat_all_nris*Hhat_all_nris')+C_totM_rsma+eyeM)\V_MR_nris;

            for k=1:K
                w = V_MMSE_rsma(:,k)/norm(V_MMSE_rsma(:,k)); %Extract precoding vector
                signal_MMSEr(k,:,indP,n) = w'*H_all_nris;
            end

        end

        %Go through all users in cell j
        for k = 1:K

            %======== Uplink =============

            %MR combining
            v = V_MR_phi1(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi1(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi1).^2) + v'*(C_totM_phi1+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MR_phi1(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            v = V_MR_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi2(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi2).^2) + v'*(C_totM_phi2+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MR_phi2(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            v = V_MR_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_nris(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_nris).^2) + v'*(C_totM_nris+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MR_nris(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            %M-MMSE combining
            v = V_MMMSE_phi1(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi1(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi1).^2) + v'*(C_totM_phi1+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MMMSE_phi1(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            v = V_MMMSE_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi2(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi2).^2) + v'*(C_totM_phi2+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MMMSE_phi2(k,n) = prelogFactor*real(log2(1+signal/interfnoise));


            v = V_MMMSE_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_nris(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_nris).^2) + v'*(C_totM_nris+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MMMSE_nris(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            %M-ZF combining
            v = V_MZF_phi1(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi1(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi1).^2) + v'*(C_totM_phi1+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MZF_phi1(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            v = V_MZF_phi2(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_phi2(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_phi2).^2) + v'*(C_totM_phi2+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MZF_phi2(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            v = V_MZF_nris(:,k); %Extract combining vector

            %Compute signal and interference+noise terms
            signal = p*abs(v'*Hhat_all_nris(:,k))^2;
            interfnoise = p*sum(abs(v'*Hhat_all_nris).^2) + v'*(C_totM_nris+eyeM)*v - signal;

            %Compute instantaneous achievable SE for one realization
            SE_MZF_nris(k,n) = prelogFactor*real(log2(1+signal/interfnoise));

            %======== Downlink =============

            %MR precoding phi1
            w = V_MR_phi1(:,k)/norm(V_MR_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MR_phi1(k) = signal_MR_phi1(k) + (w'*H_all_phi1(:,k))/nbrOfRealizations;
            interf_MR_phi1 = interf_MR_phi1 + rho*reshape(abs(w'*H_all_phi1).^2,[K 1])/nbrOfRealizations;

            %MR precoding phi2
            w = V_MR_phi2(:,k)/norm(V_MR_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MR_phi2(k) = signal_MR_phi2(k) + (w'*H_all_phi2(:,k))/nbrOfRealizations;
            interf_MR_phi2 = interf_MR_phi2 + rho*reshape(abs(w'*H_all_phi2).^2,[K 1])/nbrOfRealizations;

            %MR precoding no RIS
            w = V_MR_nris(:,k)/norm(V_MR_nris(:,k)); %Extract precoding vector

            % RSMA
            for indP=2:numPow
                signal_MRr(k,:,indP,n) = w'*H_all_nris;
            end

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MR_nris(k) = signal_MR_nris(k) + (w'*H_all_nris(:,k))/nbrOfRealizations;
            interf_MR_nris = interf_MR_nris + rho*reshape(abs(w'*H_all_nris).^2,[K 1])/nbrOfRealizations;


            %M-MMSE precoding phi1

            w = V_MMMSE_phi1(:,k)/norm(V_MMMSE_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MMMSE_phi1(k) = signal_MMMSE_phi1(k) + (w'*H_all_phi1(:,k))/nbrOfRealizations;
            interf_MMMSE_phi1 = interf_MMMSE_phi1 + rho*reshape(abs(w'*H_all_phi1).^2,[K 1])/nbrOfRealizations;

            %M-MMSE precoding phi2

            w = V_MMMSE_phi2(:,k)/norm(V_MMMSE_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MMMSE_phi2(k) = signal_MMMSE_phi2(k) + (w'*H_all_phi2(:,k))/nbrOfRealizations;
            interf_MMMSE_phi2 = interf_MMMSE_phi2 + rho*reshape(abs(w'*H_all_phi2).^2,[K 1])/nbrOfRealizations;

            %M-MMSE precoding no RIS

            w = V_MMMSE_nris(:,k)/norm(V_MMMSE_nris(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MMMSE_nris(k) = signal_MMMSE_nris(k) + (w'*H_all_nris(:,k))/nbrOfRealizations;
            interf_MMMSE_nris = interf_MMMSE_nris + rho*reshape(abs(w'*H_all_nris).^2,[K 1])/nbrOfRealizations;


            %M-ZF precoding phi1

            w = V_MZF_phi1(:,k)/norm(V_MZF_phi1(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MZF_phi1(k) = signal_MZF_phi1(k) + (w'*H_all_phi1(:,k))/nbrOfRealizations;
            interf_MZF_phi1 = interf_MZF_phi1 + rho*reshape(abs(w'*H_all_phi1).^2,[K 1])/nbrOfRealizations;

            %M-ZF precoding phi2

            w = V_MZF_phi2(:,k)/norm(V_MZF_phi2(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MZF_phi2(k) = signal_MZF_phi2(k) + (w'*H_all_phi2(:,k))/nbrOfRealizations;
            interf_MZF_phi2 = interf_MZF_phi2 + rho*reshape(abs(w'*H_all_phi2).^2,[K 1])/nbrOfRealizations;

            %M-MMSE precoding no RIS

            w = V_MZF_nris(:,k)/norm(V_MZF_nris(:,k)); %Extract precoding vector

            %Compute realizations of expectations in signal and
            %interference terms
            signal_MZF_nris(k) = signal_MZF_nris(k) + (w'*H_all_nris(:,k))/nbrOfRealizations;
            interf_MZF_nris = interf_MZF_nris + rho*reshape(abs(w'*H_all_nris).^2,[K 1])/nbrOfRealizations;


        end

    end

    %Save DL simulation results when using MMSE estimation

    % RSMA
    SignalGainWc_m = abs(mean(SignalGainWc,2)).^2;
    SignalGainWc_abs_m = mean(abs(SignalGainWc).^2,2);
    VarGainWc_m = SignalGainWc_abs_m - SignalGainWc_m;
    signal_MMSEr_m = abs(mean(signal_MMSEr,4)).^2; % K x K x numPow
    signal_MRr_m = abs(mean(signal_MRr,4)).^2; % K x K x numPow
    signal_MMSEr_abs_m = mean(abs(signal_MMSEr).^2,4); % K x K x numPow
    mui_MMSEr_m = reshape(sum(signal_MMSEr_abs_m,1),[K numPow]);
    signal_MRr_abs_m = mean(abs(signal_MRr).^2,4); % K x K x numPow
    mui_MRr_m = reshape(sum(signal_MRr_abs_m,1),[K numPow]);
    SE_MRc = zeros(1,numPow);
    SE_MMMSEc = zeros(1,numPow);
    SINR_MRp = zeros(K,numPow);
    SINR_MMMSEp = zeros(K,numPow);
    for indP =1:numPow
        SINR_MRc_UE = Pc(indP)*SignalGainWc_m./(Pp(indP)*mui_MRr_m(:,indP)+Pc(indP)*VarGainWc_m+1);
        SINR_MMMSEc_UE = Pc(indP)*SignalGainWc_m./(Pp(indP)*mui_MMSEr_m(:,indP)+Pc(indP)*VarGainWc_m+1);
        SE_MRc(1,indP) = prelogFactor*(real(log2(1+min(SINR_MRc_UE))));
        SE_MMMSEc(1,indP) = prelogFactor*(real(log2(1+min(SINR_MMMSEc_UE))));
        SINR_MRp(:,indP) = Pp(indP)*diag(signal_MRr_m(:,:,indP))./(Pp(indP)*mui_MRr_m(:,indP)-Pp(indP)*diag(signal_MRr_m(:,:,indP))+Pc(indP)*VarGainWc_m+1);
        SINR_MMMSEp(:,indP) = Pp(indP)*diag(signal_MMSEr_m(:,:,indP))./(Pp(indP)*mui_MMSEr_m(:,indP)-Pp(indP)*diag(signal_MMSEr_m(:,:,indP))+Pc(indP)*VarGainWc_m+1);
    end
    SE_MRp = prelogFactor*(real(log2(1+SINR_MRp)));
    SE_MMMSEp = prelogFactor*(real(log2(1+SINR_MMMSEp)));
    sumSEmr = SE_MRc + sum(SE_MRp,1);
    [sumSE_mr_rsma(1,m), indPopt_mr_rsma(1,m)] = max(sumSEmr);
    sumSEmmse = SE_MMMSEc + sum(SE_MMMSEp,1);
    [sumSE_mmse_rsma(1,m), indPopt_mmse_rsma(1,m)] = max(sumSEmmse);
    SE_rsma_mr_p(:,m) = SE_MRp(:,indPopt_mr_rsma(1,m));
    SE_rsma_mr_c(1,m) = SE_MRc(1,indPopt_mr_rsma(1,m));
    SE_rsma_mr_ue(:,m) = sumSE_mr_rsma(1,m)/K;
    ind_rsma_mr = SE_rsma_mr_ue(:,m)<SE_rsma_mr_p(:,m);
    temp_sumSE_mr = sumSE_mr_rsma(1,m);
    n_ind_rsma_mr = true(size(ind_rsma_mr));
    while sum(ind_rsma_mr)>0
        n_ind_rsma_mr(ind_rsma_mr) = false;
        SE_rsma_mr_ue(ind_rsma_mr,m) = SE_rsma_mr_p(ind_rsma_mr,m);
        temp_sumSE_mr = temp_sumSE_mr-sum(SE_rsma_mr_p(ind_rsma_mr,m));
        SE_rsma_mr_ue(n_ind_rsma_mr,m) = temp_sumSE_mr/sum(n_ind_rsma_mr);
        ind_rsma_mr = SE_rsma_mr_ue(:,m)<SE_rsma_mr_p(:,m);
    end
    SE_rsma_mmse_p(:,m) = SE_MMMSEp(:,indPopt_mmse_rsma(1,m));
    SE_rsma_mmse_c(1,m) = SE_MMMSEc(1,indPopt_mmse_rsma(1,m));
    SE_rsma_mmse_ue(:,m) = sumSE_mmse_rsma(1,m)/K;
    ind_rsma_mmse = SE_rsma_mmse_ue(:,m)<SE_rsma_mmse_p(:,m);
    temp_sumSE_mmse = sumSE_mmse_rsma(1,m);
    n_ind_rsma_mmse = true(size(ind_rsma_mmse));
    while sum(ind_rsma_mmse)>0
        n_ind_rsma_mmse(ind_rsma_mmse) = false;
        SE_rsma_mmse_ue(ind_rsma_mmse,m) = SE_rsma_mmse_p(ind_rsma_mmse,m);
        temp_sumSE_mmse = temp_sumSE_mmse-sum(SE_rsma_mmse_p(ind_rsma_mmse,m));
        SE_rsma_mmse_ue(n_ind_rsma_mmse,m) = temp_sumSE_mmse/sum(n_ind_rsma_mmse);
        ind_rsma_mmse = SE_rsma_mmse_ue(:,m)<SE_rsma_mmse_p(:,m);
    end

    %Compute SE with MR and phi1
    meanSEperUE_MR_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MR_phi1).^2) ./ (interf_MR_phi1 - rho*abs(signal_MR_phi1).^2 + 1)));
    
    %Compute SE with MR and phi2
    meanSEperUE_MR_mo_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MR_phi2).^2) ./ (interf_MR_phi2 - rho*abs(signal_MR_phi2).^2 + 1)));
    
    %Compute SE with MR and no RIS
    meanSEperUE_MR_nr_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MR_nris).^2) ./ (interf_MR_nris - rho*abs(signal_MR_nris).^2 + 1)));
 
    %Compute SE with M-MMSE and phi1
    meanSEperUE_MMMSE_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MMMSE_phi1).^2) ./ (interf_MMMSE_phi1 - rho*abs(signal_MMMSE_phi1).^2 + 1)));
    
    %Compute SE with M-MMSE and phi2
    meanSEperUE_MMMSE_mo_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MMMSE_phi2).^2) ./ (interf_MMMSE_phi2 - rho*abs(signal_MMMSE_phi2).^2 + 1)));

    %Compute SE with M-MMSE and no RIS
    meanSEperUE_MMMSE_nr_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MMMSE_nris).^2) ./ (interf_MMMSE_nris - rho*abs(signal_MMMSE_nris).^2 + 1)));

    %Compute SE with M-ZF and phi1
    meanSEperUE_MZF_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MZF_phi1).^2) ./ (interf_MZF_phi1 - rho*abs(signal_MZF_phi1).^2 + 1)));
    
    %Compute SE with M-ZF and phi2
    meanSEperUE_MZF_mo_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MZF_phi2).^2) ./ (interf_MZF_phi2 - rho*abs(signal_MZF_phi2).^2 + 1)));

    %Compute SE with M-ZF and no RIS
    meanSEperUE_MZF_nr_DL(:,m) = prelogFactor*real(log2(1+(rho*abs(signal_MZF_nris).^2) ./ (interf_MZF_nris - rho*abs(signal_MZF_nris).^2 + 1)));

    %Save UL simulation results when using MMSE estimation
    meanSEperUE_MR(:,m) = mean(SE_MR_phi1,2);
    meanSEperUE_MMMSE(:,m) = mean(SE_MMMSE_phi1,2);
    meanSEperUE_MZF(:,m) = mean(SE_MZF_phi1,2);

    meanSEperUE_MR_mo(:,m) = mean(SE_MR_phi2,2);
    meanSEperUE_MMMSE_mo(:,m) = mean(SE_MMMSE_phi2,2);
    meanSEperUE_MZF_mo(:,m) = mean(SE_MZF_phi2,2);

    meanSEperUE_MR_nr(:,m) = mean(SE_MR_nris,2);
    meanSEperUE_MMMSE_nr(:,m) = mean(SE_MMMSE_nris,2);
    meanSEperUE_MZF_nr(:,m) = mean(SE_MZF_nris,2);

end
   
% Averaging between all UEs in UL
meanSE_MR_rps = mean(meanSEperUE_MR,1);
meanSE_MR_mo = mean(meanSEperUE_MR_mo,1);
meanSE_MR_nr = mean(meanSEperUE_MR_nr,1);

meanSE_MMSE_rps = mean(meanSEperUE_MMMSE,1);
meanSE_MMSE_mo = mean(meanSEperUE_MMMSE_mo,1);
meanSE_MMSE_nr = mean(meanSEperUE_MMMSE_nr,1);

meanSE_MZF_rps = mean(meanSEperUE_MZF,1);
meanSE_MZF_mo = mean(meanSEperUE_MZF_mo,1);
meanSE_MZF_nr = mean(meanSEperUE_MZF_nr,1);

% Averaging between all no-RIS UEs in UL
meanSE_MR_rps_nr = mean(meanSEperUE_MR(1:tp,:),1);
meanSE_MR_mo_nr = mean(meanSEperUE_MR_mo(1:tp,:),1);
meanSE_MR_nr_nr = mean(meanSEperUE_MR_nr(1:tp,:),1);

meanSE_MMSE_rps_nr = mean(meanSEperUE_MMMSE(1:tp,:),1);
meanSE_MMSE_mo_nr = mean(meanSEperUE_MMMSE_mo(1:tp,:),1);
meanSE_MMSE_nr_nr = mean(meanSEperUE_MMMSE_nr(1:tp,:),1);

meanSE_MZF_rps_nr = mean(meanSEperUE_MZF(1:tp,:),1);
meanSE_MZF_mo_nr = mean(meanSEperUE_MZF_mo(1:tp,:),1);
meanSE_MZF_nr_nr = mean(meanSEperUE_MZF_nr(1:tp,:),1);

% Averaging between all RIS UEs in UL
meanSE_MR_rps_r = mean(meanSEperUE_MR(tp+1:end,:),1);
meanSE_MR_mo_r = mean(meanSEperUE_MR_mo(tp+1:end,:),1);
meanSE_MR_nr_r = mean(meanSEperUE_MR_nr(tp+1:end,:),1);

meanSE_MMSE_rps_r = mean(meanSEperUE_MMMSE(tp+1:end,:),1);
meanSE_MMSE_mo_r = mean(meanSEperUE_MMMSE_mo(tp+1:end,:),1);
meanSE_MMSE_nr_r = mean(meanSEperUE_MMMSE_nr(tp+1:end,:),1);

meanSE_MZF_rps_r = mean(meanSEperUE_MZF(tp+1:end,:),1);
meanSE_MZF_mo_r = mean(meanSEperUE_MZF_mo(tp+1:end,:),1);
meanSE_MZF_nr_r = mean(meanSEperUE_MZF_nr(tp+1:end,:),1);

% Averaging between all UEs in DL
meanSE_MR_rps_DL = mean(meanSEperUE_MR_DL,1);
meanSE_MR_mo_DL = mean(meanSEperUE_MR_mo_DL,1);
meanSE_MR_nr_DL = mean(meanSEperUE_MR_nr_DL,1);

meanSE_MMSE_rps_DL = mean(meanSEperUE_MMMSE_DL,1);
meanSE_MMSE_mo_DL = mean(meanSEperUE_MMMSE_mo_DL,1);
meanSE_MMSE_nr_DL = mean(meanSEperUE_MMMSE_nr_DL,1);

meanSE_MZF_rps_DL = mean(meanSEperUE_MZF_DL,1);
meanSE_MZF_mo_DL = mean(meanSEperUE_MZF_mo_DL,1);
meanSE_MZF_nr_DL = mean(meanSEperUE_MZF_nr_DL,1);

% Averaging between all no-RIS UEs in DL
meanSE_MR_rps_nr_DL = mean(meanSEperUE_MR_DL(1:tp,:),1);
meanSE_MR_mo_nr_DL = mean(meanSEperUE_MR_mo_DL(1:tp,:),1);
meanSE_MR_nr_nr_DL = mean(meanSEperUE_MR_nr_DL(1:tp,:),1);

meanSE_MMSE_rps_nr_DL = mean(meanSEperUE_MMMSE_DL(1:tp,:),1);
meanSE_MMSE_mo_nr_DL = mean(meanSEperUE_MMMSE_mo_DL(1:tp,:),1);
meanSE_MMSE_nr_nr_DL = mean(meanSEperUE_MMMSE_nr_DL(1:tp,:),1);

meanSE_MZF_rps_nr_DL = mean(meanSEperUE_MZF_DL(1:tp,:),1);
meanSE_MZF_mo_nr_DL = mean(meanSEperUE_MZF_mo_DL(1:tp,:),1);
meanSE_MZF_nr_nr_DL = mean(meanSEperUE_MZF_nr_DL(1:tp,:),1);

% Averaging between all RIS UEs in DL
meanSE_MR_rps_r_DL = mean(meanSEperUE_MR_DL(tp+1:end,:),1);
meanSE_MR_mo_r_DL = mean(meanSEperUE_MR_mo_DL(tp+1:end,:),1);
meanSE_MR_nr_r_DL = mean(meanSEperUE_MR_nr_DL(tp+1:end,:),1);

meanSE_MMSE_rps_r_DL = mean(meanSEperUE_MMMSE_DL(tp+1:end,:),1);
meanSE_MMSE_mo_r_DL = mean(meanSEperUE_MMMSE_mo_DL(tp+1:end,:),1);
meanSE_MMSE_nr_r_DL = mean(meanSEperUE_MMMSE_nr_DL(tp+1:end,:),1);

meanSE_MZF_rps_r_DL = mean(meanSEperUE_MZF_DL(tp+1:end,:),1);
meanSE_MZF_mo_r_DL = mean(meanSEperUE_MZF_mo_DL(tp+1:end,:),1);
meanSE_MZF_nr_r_DL = mean(meanSEperUE_MZF_nr_DL(tp+1:end,:),1);


% Plot simulation results

% Generating Fig. 4
%Plot spatial configuration
figure

plot(real(BSlocations),imag(BSlocations),'kh')
hold on; box on; grid on;
plot(real(posUE1(:,1)),imag(posUE1(:,1)),'bo')
plot(real(posRIS),imag(posRIS),'r+')
plot(real(posUEs),imag(posUEs),'rv')
legend('BS','UEs w/o RIS','RIS','UEs with RIS')
xlim([-1*cellRadius cellRadius])
ylim([-1*cellRadius cellRadius])
xlabel('distance [m]')
ylabel('distance [m]')


% Generating Fig. 6
figure;
subplot(1,2,1)
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr_nr,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr_nr,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr_nr,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps_nr,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps_nr,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_nr,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo_nr,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo_nr,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_nr,'rd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('SE UEs w/o RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
set(gca,'XScale','log');

subplot(1,2,2)
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr_r,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr_r,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr_r,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps_r,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps_r,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_r,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo_r,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo_r,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_r,'rd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('SE UEs with RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
set(gca,'XScale','log');

% Generating Fig. 5
figure
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo,'rd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('Spectral efficiency [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','Location','NorthWest');
set(gca,'XScale','log');


% Generating Fig. 11
figure;
subplot(1,2,1)
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr_nr_DL,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr_nr_DL,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr_nr_DL,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps_nr_DL,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps_nr_DL,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_nr_DL,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo_nr_DL,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo_nr_DL,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_nr_DL,'rd:','LineWidth',1);
plot(Mrange,SE_rsma_mr_p(1,:) + SE_rsma_mr_c/K,'m+--','LineWidth',1);
plot(Mrange,SE_rsma_mmse_p(1,:) + SE_rsma_mmse_c/K,'mx--','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('DL SE Closest UEs w/o RIS [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','MR RSMA','MMSE RSMA','Location','NorthWest');
set(gca,'XScale','log');

subplot(1,2,2)
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr_r_DL,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr_r_DL,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr_r_DL,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps_r_DL,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps_r_DL,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_r_DL,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo_r_DL,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo_r_DL,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_r_DL,'rd:','LineWidth',1);
plot(Mrange,mean(SE_rsma_mr_p(2:end,:),1) + SE_rsma_mr_c/K,'m+--','LineWidth',1);
plot(Mrange,mean(SE_rsma_mmse_p(2:end,:),1) + SE_rsma_mmse_c/K,'mx--','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('DL SE RIS-aided UEs [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','MR RSMA','MMSE RSMA','Location','NorthWest');
set(gca,'XScale','log');

% Generating Fig. 10
figure
hold on; box on; grid on;
plot(Mrange,meanSE_MR_nr_DL,'bs-','LineWidth',1);
plot(Mrange,meanSE_MZF_nr_DL,'ko-','LineWidth',1);
plot(Mrange,meanSE_MMSE_nr_DL,'rd-','LineWidth',1);
plot(Mrange,meanSE_MR_rps_DL,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MZF_rps_DL,'ko-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_DL,'rd-.','LineWidth',1);
plot(Mrange,meanSE_MR_mo_DL,'bs:','LineWidth',1);
plot(Mrange,meanSE_MZF_mo_DL,'ko:','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_DL,'rd:','LineWidth',1);
plot(Mrange,sumSE_mr_rsma/K,'m+--','LineWidth',1);
plot(Mrange,sumSE_mmse_rsma/K,'mx--','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('DL Spectral efficiency [bit/s/Hz/user]');

legend('MR nr','ZF nr','MMSE nr','MR rps','ZF rps','MMSE rps','MR mo','ZF mo','MMSE mo','MR RSMA','MMSE RSMA','Location','NorthWest');
set(gca,'XScale','log');

% Generating Fig. 7
figure
subplot(1,3,1)
hold on; box on; grid on;
plot(Mrange,meanSE_MMSE_nr_nr,'ro-','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_nr,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_nr,'kd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('SE Closest UEs w/o RIS [bit/s/Hz/user]');
set(gca,'XScale','log');

subplot(1,3,2)
hold on; box on; grid on;
plot(Mrange,meanSE_MMSE_nr_r,'ro-','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps_r,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo_r,'kd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('SE Farthest UEs with RIS [bit/s/Hz/user]');
legend('MMSE nr','MMSE rps','MMSE mo','Location','NorthWest');
set(gca,'XScale','log');

subplot(1,3,3)
hold on; box on; grid on;
plot(Mrange,meanSE_MMSE_nr,'ro-','LineWidth',1);
plot(Mrange,meanSE_MMSE_rps,'bs-.','LineWidth',1);
plot(Mrange,meanSE_MMSE_mo,'kd:','LineWidth',1);

xlabel('Number of antennas (M)');
ylabel('Average SE [bit/s/Hz/user]');

legend('MMSE nr','MMSE rps','MMSE mo','Location','NorthWest');
set(gca,'XScale','log');

